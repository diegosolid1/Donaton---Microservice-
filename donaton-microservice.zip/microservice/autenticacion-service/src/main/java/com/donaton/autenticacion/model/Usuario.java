package com.donaton.autenticacion.model;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Usuario")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    @Column(name = "nombre")
    private String nombre;

    @NotBlank(message = "El correo electrónico es obligatorio")
    @Size(max = 150, message = "El correo no puede superar los 150 caracteres")
    @Column(name = "correo")
    private String correo;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(max = 255, message = "El hash de la contraseña no puede superar los 255 caracteres")
    @Column(name = "password_hash")
    private String passwordHash;

    @NotNull(message = "El rol del usuario es obligatorio")
    @ManyToOne
    @JoinColumn(name = "id_rol")
    private Rol rol;
}

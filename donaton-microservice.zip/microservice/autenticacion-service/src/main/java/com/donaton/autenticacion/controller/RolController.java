package com.donaton.autenticacion.controller;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import com.donaton.autenticacion.model.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.donaton.autenticacion.service.RolService;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/rol")
@Tag(name = "Roles", description = "Operaciones relacionadas con la gestión de roles")
public class RolController {

    @Autowired
    private RolService rolService;

    @Operation(summary = "Obtener todos los roles")
    @GetMapping
    public ResponseEntity<List<Rol>> obtenerTodos() {
        List<Rol> roles = rolService.listarTodos();

        if (roles.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204 No Content
        } else {
            return ResponseEntity.ok(roles); // 200 OK
        }
    }

    @Operation(summary = "Obtener un rol por su ID")
    @GetMapping("/{id}")
   /*
        public ResponseEntity<Rol> obtenerPorId(@PathVariable Integer id) {
         Optional<Rol> rol = rolService.buscarPorId(id);

          if (rol.isPresent()) {
        return ResponseEntity.ok(rol.get()); // 200 OK
    } else {
        return ResponseEntity.notFound().build(); // 404 Not Found
    }
}
*/
    public EntityModel<Rol> getRol(@PathVariable Integer id) {

        Rol rol = rolService.buscarPorId(id).orElseThrow();
        EntityModel<Rol> model = EntityModel.of(rol);

        model.add(
                linkTo(
                        methodOn(RolController.class)
                                .getRol(id)).withSelfRel()
        );
        return model;
    }


    @Operation(summary = "Crear un nuevo rol")
    @PostMapping
    public ResponseEntity<Rol> crear(@Valid @RequestBody Rol rol) {
        Rol nuevoRol = rolService.guardar(rol);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201 Created
                .body(nuevoRol);
    }

    @Operation(summary = "Actualizar un rol existente")
    @PutMapping("/{id}")
    public ResponseEntity<Rol> actualizar(@Valid @RequestBody Rol rol, @PathVariable Integer id) {
        Optional<Rol> existe = rolService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }

        rol.setId(id);
        Rol actualizado = rolService.guardar(rol);
        return ResponseEntity.ok(actualizado); // 200 OK
    }

    @Operation(summary = "Eliminar un rol por su ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        try {
            rolService.eliminar(id);
            return ResponseEntity.noContent().build(); // 204 No Content
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    }
}
package com.donaton.autenticacion.service;


import com.donaton.autenticacion.model.Rol;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.donaton.autenticacion.repository.RolRepository;

import java.util.List;
import java.util.Optional;

@Service
public class RolService {

    @Autowired
    private RolRepository rolRepository;

    public List<Rol> listarTodos() {
        return rolRepository.findAll();
    }

    public Optional<Rol> buscarPorId(Integer id) {
        return rolRepository.findById(id);
    }

    public Rol guardar(Rol rol) {
        return rolRepository.save(rol);
    }

    public void eliminar(Integer id) {
        rolRepository.deleteById(id);
    }

    public Rol actualizar(Integer id, Rol rol) {
        Optional<Rol> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Rol no encontrado con el ID: " + id);
        } else {
            rol.setId(id);
            return rolRepository.save(rol);
        }
    }

}

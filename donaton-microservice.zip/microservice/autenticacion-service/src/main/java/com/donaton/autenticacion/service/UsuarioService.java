package com.donaton.autenticacion.service;

import com.donaton.autenticacion.model.Usuario;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.donaton.autenticacion.repository.UsuarioRepository;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll();

    }

    public Optional<Usuario> buscarPorId(Integer id) {
        return usuarioRepository.findById(id);
    }

    public Usuario guardar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public void eliminar(Integer id) {
        usuarioRepository.deleteById(id);
    }

    public Usuario actualizar(Integer id, Usuario usuario) {
        Optional<Usuario> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Usuario no encontrado con el ID: " + id);
        } else {

            usuario.setIdUsuario(id);
            return usuarioRepository.save(usuario);
        }
    }

}

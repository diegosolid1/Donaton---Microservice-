-- V4__alter_usuario_id.sql

ALTER TABLE Usuario
    CHANGE COLUMN id id_usuario INT AUTO_INCREMENT;

-- 1. Insertar Roles
INSERT INTO Rol (id, nombre_rol) VALUES
                                     (1, 'Administrador'),
                                     (2, 'Donante'),
                                     (3, 'Voluntario'),
                                     (4, 'Institucion');

-- 2. Insertar Usuarios
INSERT INTO Usuario (nombre, correo, password_hash, id_rol) VALUES
-- Administradores (id_rol = 1)
('Carlos Mendoza (Admin)', 'admin@sistema.com', '$2y$10$W9M...hash_simulado_admin...X72', 1),
('Laura Torres (Admin)', 'laura.admin@sistema.com', '$2y$10$A1B...hash_simulado_admin...Y83', 1),

-- Donantes (id_rol = 2)
('Juan Pérez', 'juan.perez@email.com', '$2y$10$Z3C...hash_simulado_donante...Q91', 2),
('María González', 'maria.gonzalez@email.com', '$2y$10$Y4D...hash_simulado_donante...W82', 2),
('Empresa XYZ S.A.', 'donaciones@empresaxyz.com', '$2y$10$X5E...hash_simulado_donante...E73', 2),

-- Voluntarios (id_rol = 3)
('Pedro Sánchez', 'pedro.voluntario@email.com', '$2y$10$V6F...hash_simulado_volunt...R64', 3),
('Ana López', 'ana.lopez@email.com', '$2y$10$U7G...hash_simulado_volunt...T55', 3),
('Roberto Gómez', 'roberto.gomez@email.com', '$2y$10$T8H...hash_simulado_volunt...Y46', 3),
('Lucía Fernández', 'lucia.f@email.com', '$2y$10$S9I...hash_simulado_volunt...U37', 3),

-- Instituciones (id_rol = 4)
('Fundación Manos Abiertas', 'contacto@manosabiertas.org', '$2y$10$R0J...hash_simulado_instit...I28', 4),
('Hospital San Juan', 'direcciones@hospitalsanjuan.gob', '$2y$10$Q1K...hash_simulado_instit...O19', 4),
('Escuela Rural Esperanza', 'info@escuelaesperanza.edu', '$2y$10$P2L...hash_simulado_instit...P00', 4);
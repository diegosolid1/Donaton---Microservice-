package com.donaton.autenticacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

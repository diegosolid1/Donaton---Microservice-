package com.donaton.autenticacion;

import com.donaton.autenticacion.model.Rol;
import com.donaton.autenticacion.model.Usuario;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionAutenticacionTest {

    // ==========================================
    // TESTS DE USUARIO
    // ==========================================

    @Test
    void registrarUsuario() {
        Usuario usuario = new Usuario();
        Faker faker = new Faker();

        usuario.setNombre(faker.name().fullName());
        usuario.setCorreo(faker.internet().emailAddress());
        usuario.setPasswordHash(faker.internet().password());

        System.out.println("Nombre: " + usuario.getNombre());
        System.out.println("Correo: " + usuario.getCorreo());
        System.out.println("Password: " + usuario.getPasswordHash());

        assertNotNull(usuario);
    }

    @Test
    void probarPass() {
        Usuario usuario = new Usuario();
        Faker faker = new Faker();

        String password = faker.internet().password(8, 16);

        usuario.setCorreo(faker.internet().emailAddress());
        usuario.setPasswordHash(password);

        System.out.println("Password generada: " + usuario.getPasswordHash());

        assertNotNull(usuario);
        assertEquals(password, usuario.getPasswordHash());
    }

    @Test
    void probarNombre() {
        Usuario usuario = new Usuario();
        Faker faker = new Faker();

        String nombre = faker.name().fullName();
        usuario.setNombre(nombre);

        System.out.println("Nombre: " + usuario.getNombre());

        assertEquals(nombre, usuario.getNombre());
    }

    @Test
    void probarCorreo() {
        Usuario usuario = new Usuario();
        usuario.setCorreo("juan@gmail.com");

        System.out.println("Correo: " + usuario.getCorreo());

        assertEquals("juan@gmail.com", usuario.getCorreo());
    }

    // ==========================================
    // TESTS DE ROL
    // ==========================================

    @Test
    void registrarRol() {
        Rol rol = new Rol();
        Faker faker = new Faker();

        rol.setId(faker.number().positive());

        // Obtener un rol aleatorio del Enum RolNombre
        Rol.RolNombre[] roles = Rol.RolNombre.values();
        Rol.RolNombre rolAleatorio = roles[faker.random().nextInt(roles.length)];
        rol.setNombreRol(rolAleatorio);

        System.out.println("ID Rol: " + rol.getId());
        System.out.println("Nombre Rol: " + rol.getNombreRol());

        assertNotNull(rol);
        assertNotNull(rol.getNombreRol());
    }

    @Test
    void probarNombreRol() {
        Rol rol = new Rol();

        // Probamos asignando un rol específico (ej. Voluntario)
        Rol.RolNombre nombreEsperado = Rol.RolNombre.Voluntario;
        rol.setNombreRol(nombreEsperado);

        System.out.println("Rol asignado: " + rol.getNombreRol());

        assertEquals(nombreEsperado, rol.getNombreRol());
    }

    @Test
    void probarIdRol() {
        Rol rol = new Rol();
        Faker faker = new Faker();

        Integer idEsperado = faker.number().positive();
        rol.setId(idEsperado);

        System.out.println("ID de Rol generado: " + rol.getId());

        assertEquals(idEsperado, rol.getId());
    }
}
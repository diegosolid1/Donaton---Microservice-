DROP TABLE IF EXISTS `asignacionturno`;
DROP TABLE IF EXISTS `voluntario`;

-- Estructura de tabla para `voluntario`
CREATE TABLE `voluntario` (
                              `id_voluntario` INT NOT NULL AUTO_INCREMENT,
                              `id_usuario` INT NOT NULL,
                              `area_especialidad` ENUM('Salud', 'Rescate', 'Logistica', 'Apoyo_Emocional', 'General') NOT NULL,
                              `estado_disponibilidad` TINYINT(1) NOT NULL DEFAULT 1,
                              PRIMARY KEY (`id_voluntario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Estructura de tabla para `asignacionturno`
CREATE TABLE `asignacionturno` (
                                   `id_asignacion_turno` INT NOT NULL AUTO_INCREMENT,
                                   `id_voluntario` INT NOT NULL,
                                   `id_acopio` INT NOT NULL,
                                   `fecha_turno` DATE NOT NULL,
                                   `bloque_horario` ENUM('Mañana', 'Tarde', 'Noche') NOT NULL,
                                   PRIMARY KEY (`id_asignacion_turno`),
                                   KEY `fk_voluntario_turno` (`id_voluntario`),
                                   CONSTRAINT `fk_voluntario_turno` FOREIGN KEY (`id_voluntario`) REFERENCES `voluntario` (`id_voluntario`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- Volcado de datos para la tabla `voluntario`
INSERT INTO `voluntario` (`id_voluntario`, `id_usuario`, `area_especialidad`, `estado_disponibilidad`) VALUES
                                                                                                           (1, 101, 'General', 1),
                                                                                                           (2, 102, 'Salud', 1),
                                                                                                           (3, 103, 'Rescate', 1),
                                                                                                           (4, 104, 'Logistica', 0),
                                                                                                           (5, 105, 'Apoyo_Emocional', 1),
                                                                                                           (6, 106, 'General', 1),
                                                                                                           (7, 107, 'Salud', 0),
                                                                                                           (8, 108, 'Rescate', 1),
                                                                                                           (9, 109, 'Logistica', 1),
                                                                                                           (10, 110, 'Apoyo_Emocional', 0);

-- Volcado de datos para la tabla `asignacionturno`
INSERT INTO `asignacionturno` (`id_asignacion_turno`, `id_voluntario`, `id_acopio`, `fecha_turno`, `bloque_horario`) VALUES
                                                                                                                         (1, 2, 301, '2026-06-01', 'Mañana'),
                                                                                                                         (2, 3, 302, '2026-06-01', 'Tarde'),
                                                                                                                         (3, 4, 303, '2026-06-02', 'Noche'),
                                                                                                                         (4, 5, 304, '2026-06-02', 'Mañana'),
                                                                                                                         (5, 6, 305, '2026-06-03', 'Tarde'),
                                                                                                                         (6, 7, 306, '2026-06-03', 'Noche'),
                                                                                                                         (7, 8, 307, '2026-06-04', 'Mañana'),
                                                                                                                         (8, 9, 308, '2026-06-04', 'Tarde'),
                                                                                                                         (9, 10, 309, '2026-06-05', 'Noche'),
                                                                                                                         (10, 1, 310, '2026-06-05', 'Mañana');
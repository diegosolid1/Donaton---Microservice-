package com.donaton.voluntariado_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AsignacionTurno")
public class AsignacionTurno {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_asignacion_turno")
    private Integer idAsignacionTurno;

    @NotNull(message = "El voluntario asignado es obligatorio")
    @ManyToOne
    @JoinColumn(name = "id_voluntario")
    private Voluntario voluntario;

    @NotNull(message = "El ID del centro de acopio es obligatorio")
    @Column(name = "id_acopio")
    private Integer idAcopio;

    @NotNull(message = "La fecha del turno es obligatoria")
    @Column(name = "fecha_turno")
    private LocalDate fechaTurno;

    @NotNull(message = "El bloque horario es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "bloque_horario", columnDefinition = "ENUM('Mañana', 'Tarde', 'Noche')")
    private BloqueHorario bloqueHorario;

    public enum BloqueHorario {
        Mañana,
        Tarde,
        Noche;
    }
}
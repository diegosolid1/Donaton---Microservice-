package com.donaton.voluntariado_service.controller;

import com.donaton.voluntariado_service.model.AsignacionTurno;
import com.donaton.voluntariado_service.service.AsignacionTurnoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/asignacion-turno")
@Tag(name = "Asignación de Turnos", description = "Operaciones de gestión y distribución de turnos para los voluntarios.")
public class AsignacionTurnoController {

    @Autowired
    private AsignacionTurnoService asignacionTurnoService;

    @Operation(summary = "Listar todas las asignaciones de turnos.")
    @GetMapping
    public ResponseEntity<List<AsignacionTurno>> listarAsignacionesTurno() {
        List<AsignacionTurno> asignaciones = asignacionTurnoService.getAsignacionesTurno();

        if (asignaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(asignaciones);
        }
    }

    @Operation(summary = "Obtener una asignación de turno por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<AsignacionTurno> buscarPorId(@PathVariable Integer id) { // Cambiado a Integer
        Optional<AsignacionTurno> asignacion = asignacionTurnoService.getAsignacionTurno(id);

        if (asignacion.isPresent()) {
            return ResponseEntity.ok(asignacion.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    } */
    public EntityModel<AsignacionTurno> getAsignacionTurno(@PathVariable Integer id) {

        AsignacionTurno asignacionTurno = asignacionTurnoService.getAsignacionTurno(id).orElseThrow();
        EntityModel<AsignacionTurno> model = EntityModel.of(asignacionTurno);

        model.add(
                linkTo(
                        methodOn(AsignacionTurnoController.class)
                                .getAsignacionTurno(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva asignación de turno.")
    @PostMapping
    public ResponseEntity<AsignacionTurno> agregarAsignacionTurno(@Valid @RequestBody AsignacionTurno asignacionTurno) {
        try {
            AsignacionTurno nuevaAsignacion = asignacionTurnoService.saveAsignacionTurno(asignacionTurno);
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(nuevaAsignacion);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar una asignación de turno existente.")
    @PutMapping("/{id}")
    public ResponseEntity<AsignacionTurno> editarAsignacionTurno(@Valid @RequestBody AsignacionTurno asignacionTurno, @PathVariable Integer id) { // Cambiado a Integer
        Optional<AsignacionTurno> existe = asignacionTurnoService.getAsignacionTurno(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        asignacionTurno.setIdAsignacionTurno(id);
        try {
            AsignacionTurno actualizada = asignacionTurnoService.saveAsignacionTurno(asignacionTurno);
            return ResponseEntity.ok(actualizada);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar una asignación de turno por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarAsignacionTurno(@PathVariable Integer id) { // Cambiado a Integer
        try {
            asignacionTurnoService.deleteAsignacionTurno(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }



}
package com.donaton.voluntariado_service.dto;
import lombok.Data;

@Data
//@JsonIgnoreProperties(ignoreUnknown = true)
public class UsuarioDTO {
    private Integer idUsuario;
    private String nombre;
    private String correo;
    private RolDTO rol;}
package com.donaton.voluntariado_service.repository;

import com.donaton.voluntariado_service.model.AsignacionTurno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AsignacionTurnoRepository extends JpaRepository<AsignacionTurno, Integer> {

}
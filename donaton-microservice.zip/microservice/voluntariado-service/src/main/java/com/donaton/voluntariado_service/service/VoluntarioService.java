package com.donaton.voluntariado_service.service;

import com.donaton.voluntariado_service.client.AutenticacionClient;
import com.donaton.voluntariado_service.dto.UsuarioDTO;
import com.donaton.voluntariado_service.model.Voluntario;
import com.donaton.voluntariado_service.repository.VoluntarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VoluntarioService {

    @Autowired
    private VoluntarioRepository voluntarioRepository;

    @Autowired
    private AutenticacionClient autenticacionClient;

    // Obtener todos los voluntarios
    public List<Voluntario> getVoluntarios() {
        return voluntarioRepository.findAll();
    }

    // Obtener un voluntario por su ID
    public Optional<Voluntario> getVoluntario(Integer id) {
        return voluntarioRepository.findById(id);
    }

    // Guardar o crear un nuevo voluntario
    public Voluntario saveVoluntario(Voluntario voluntario) {
        return voluntarioRepository.save(voluntario);
    }

    // Actualizar un voluntario existente
    public Voluntario updateVoluntario(Integer id, Voluntario voluntario) {
        Optional<Voluntario> existe = getVoluntario(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Voluntario no encontrado con el ID: " + id);
        } else {
            voluntario.setIdVoluntario(id);
            return voluntarioRepository.save(voluntario);
        }
    }

    // Eliminar un voluntario por ID
    public void deleteVoluntario(Integer id) {
        if (voluntarioRepository.existsById(id)) {
            voluntarioRepository.deleteById(id);
        } else {
            throw new RuntimeException("Voluntario no encontrado con el ID: " + id);
        }
    }

    public List<UsuarioDTO> obtenerUsuariosExternos() {
        return autenticacionClient.obtenerUsuarios();
    }
}
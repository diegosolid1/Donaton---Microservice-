package com.donaton.voluntariado_service.service;

import com.donaton.voluntariado_service.model.AsignacionTurno;
import com.donaton.voluntariado_service.repository.AsignacionTurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AsignacionTurnoService {

    @Autowired
    private AsignacionTurnoRepository asignacionTurnoRepository;

    // Obtener todas las asignaciones
    public List<AsignacionTurno> getAsignacionesTurno() {
        return asignacionTurnoRepository.findAll();
    }

    // Obtener una asignación por su ID
    public Optional<AsignacionTurno> getAsignacionTurno(Integer id) {
        return asignacionTurnoRepository.findById(id);
    }

    // Guardar o crear una nueva asignación
    public AsignacionTurno saveAsignacionTurno(AsignacionTurno asignacionTurno) {
        return asignacionTurnoRepository.save(asignacionTurno);
    }

    // Actualizar una asignación existente
    public AsignacionTurno updateAsignacionTurno(Integer id, AsignacionTurno asignacionTurno) {
        Optional<AsignacionTurno> existe = getAsignacionTurno(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Asignación de turno no encontrada con el ID: " + id);
        } else {
            asignacionTurno.setIdAsignacionTurno(id);
            return asignacionTurnoRepository.save(asignacionTurno);
        }
    }

    // Eliminar una asignación por ID
    public void deleteAsignacionTurno(Integer id) {
        if (asignacionTurnoRepository.existsById(id)) {
            asignacionTurnoRepository.deleteById(id);
        } else {
            throw new RuntimeException("Asignación de turno no encontrada con el ID: " + id);
        }
    }
}
package com.donaton.voluntariado_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Voluntario")
public class Voluntario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_voluntario")
    private Integer idVoluntario;

    @NotNull(message = "El ID de usuario es obligatorio")
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @NotNull(message = "El área de especialidad es obligatoria")
    @Enumerated(EnumType.STRING)
    @Column(name = "area_especialidad", columnDefinition = "ENUM('Salud', 'Rescate', 'Logistica', 'Apoyo_Emocional', 'General')")
    private AreaEspecialidad areaEspecialidad;

    @NotNull(message = "El estado de disponibilidad es obligatorio")
    @Column(name = "estado_disponibilidad")
    private Boolean estadoDisponibilidad = true;

    public enum AreaEspecialidad {
        Salud,
        Rescate,
        Logistica,
        Apoyo_Emocional,
        General;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "voluntario", cascade = CascadeType.ALL)
    private List<AsignacionTurno> turnos;
}
package com.donaton.voluntariado_service.controller;

import com.donaton.voluntariado_service.dto.UsuarioDTO;
import com.donaton.voluntariado_service.model.Voluntario;
import com.donaton.voluntariado_service.service.VoluntarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/voluntario")
@Tag(name = "Voluntarios", description = "Operaciones de registro y gestión de la información de voluntarios.")
public class VoluntarioController {

    @Autowired
    private VoluntarioService voluntarioService;

    @Operation(summary = "Listar todos los voluntarios.")
    @GetMapping
    public ResponseEntity<List<Voluntario>> listarVoluntarios() {
        List<Voluntario> voluntarios = voluntarioService.getVoluntarios();

        if (voluntarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(voluntarios);
        }
    }

    @Operation(summary = "Obtener un voluntario por ID.")
    @GetMapping("/{id}")
   /* public ResponseEntity<Voluntario> buscarPorId(@PathVariable Integer id) { // Cambiado a Integer
        Optional<Voluntario> voluntario = voluntarioService.getVoluntario(id);

        if (voluntario.isPresent()) {
            return ResponseEntity.ok(voluntario.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    } */
    public EntityModel<Voluntario> getVoluntario(@PathVariable Integer id) {

        Voluntario voluntario = voluntarioService.getVoluntario(id).orElseThrow();
        EntityModel<Voluntario> model = EntityModel.of(voluntario);

        model.add(
                linkTo(
                        methodOn(VoluntarioController.class)
                                .getVoluntario(id)).withSelfRel()
        );


        return model;
    }

    @Operation(summary = "Registrar un nuevo voluntario.")
    @PostMapping
    public ResponseEntity<Voluntario> agregarVoluntario(@Valid @RequestBody Voluntario voluntario) {
        try {
            Voluntario nuevoVoluntario = voluntarioService.saveVoluntario(voluntario);
            return ResponseEntity
                    .status(HttpStatus.CREATED)
                    .body(nuevoVoluntario);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar un voluntario existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Voluntario> editarVoluntario(@Valid @RequestBody Voluntario voluntario, @PathVariable Integer id) { // Cambiado a Integer
        Optional<Voluntario> existe = voluntarioService.getVoluntario(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        voluntario.setIdVoluntario(id);
        try {
            Voluntario actualizado = voluntarioService.saveVoluntario(voluntario);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar un voluntario por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarVoluntario(@PathVariable Integer id) { // Cambiado a Integer
        try {
            voluntarioService.deleteVoluntario(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Listar usuarios externos asociados.")
    @GetMapping("/usuario")
    public ResponseEntity<List<UsuarioDTO>> listarUsuarios() {
        List<UsuarioDTO> usuarios = voluntarioService.obtenerUsuariosExternos();

        if (usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(usuarios);
        }
    }



}
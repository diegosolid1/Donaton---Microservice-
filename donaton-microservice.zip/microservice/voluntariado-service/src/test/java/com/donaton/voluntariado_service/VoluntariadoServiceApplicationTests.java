package com.donaton.voluntariado_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoluntariadoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

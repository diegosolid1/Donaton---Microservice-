package com.donaton.voluntariado_service;

import com.donaton.voluntariado_service.model.AsignacionTurno;
import com.donaton.voluntariado_service.model.Voluntario;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GestionVoluntariadoTest {

    // ==========================================
    // TESTS DE VOLUNTARIO
    // ==========================================

    @Test
    void registrarVoluntario() {
        Voluntario voluntario = new Voluntario();
        Faker faker = new Faker();

        voluntario.setIdVoluntario(faker.number().positive());
        voluntario.setIdUsuario(faker.number().positive());
        voluntario.setEstadoDisponibilidad(faker.bool().bool());

        // Obtener un área aleatoria del Enum AreaEspecialidad
        Voluntario.AreaEspecialidad[] areas = Voluntario.AreaEspecialidad.values();
        Voluntario.AreaEspecialidad areaAleatoria = areas[faker.random().nextInt(areas.length)];
        voluntario.setAreaEspecialidad(areaAleatoria);

        System.out.println("ID Voluntario: " + voluntario.getIdVoluntario());
        System.out.println("ID Usuario: " + voluntario.getIdUsuario());
        System.out.println("Estado Disponibilidad: " + voluntario.getEstadoDisponibilidad());
        System.out.println("Área Especialidad: " + voluntario.getAreaEspecialidad());

        assertNotNull(voluntario);
        assertNotNull(voluntario.getAreaEspecialidad());
        assertNotNull(voluntario.getEstadoDisponibilidad());
    }

    @Test
    void probarIdsYDisponibilidadVoluntario() {
        Voluntario voluntario = new Voluntario();

        Integer idUsuarioEsperado = 55;
        Boolean disponibilidadEsperada = true;

        voluntario.setIdUsuario(idUsuarioEsperado);
        voluntario.setEstadoDisponibilidad(disponibilidadEsperada);

        System.out.println("ID Usuario asignado: " + voluntario.getIdUsuario());
        System.out.println("Disponibilidad asignada: " + voluntario.getEstadoDisponibilidad());

        assertEquals(idUsuarioEsperado, voluntario.getIdUsuario());
        assertTrue(voluntario.getEstadoDisponibilidad());
    }

    @Test
    void probarAreaEspecialidad() {
        Voluntario voluntario = new Voluntario();

        Voluntario.AreaEspecialidad areaEsperada = Voluntario.AreaEspecialidad.Rescate;
        voluntario.setAreaEspecialidad(areaEsperada);

        System.out.println("Área de especialidad asignada: " + voluntario.getAreaEspecialidad());

        assertEquals(areaEsperada, voluntario.getAreaEspecialidad());
    }

    // ==========================================
    // TESTS DE ASIGNACIÓN DE TURNO
    // ==========================================

    @Test
    void registrarAsignacionTurno() {
        AsignacionTurno turno = new AsignacionTurno();
        Faker faker = new Faker();

        turno.setIdAsignacionTurno(faker.number().positive());
        turno.setIdAcopio(faker.number().positive());
        turno.setFechaTurno(LocalDate.now());

        // Obtener un bloque horario aleatorio del Enum
        AsignacionTurno.BloqueHorario[] bloques = AsignacionTurno.BloqueHorario.values();
        AsignacionTurno.BloqueHorario bloqueAleatorio = bloques[faker.random().nextInt(bloques.length)];
        turno.setBloqueHorario(bloqueAleatorio);

        System.out.println("ID Asignación Turno: " + turno.getIdAsignacionTurno());
        System.out.println("ID Acopio: " + turno.getIdAcopio());
        System.out.println("Fecha Turno: " + turno.getFechaTurno());
        System.out.println("Bloque Horario: " + turno.getBloqueHorario());

        assertNotNull(turno);
        assertNotNull(turno.getFechaTurno());
        assertNotNull(turno.getBloqueHorario());
    }

    @Test
    void probarAcopioYFechaTurno() {
        AsignacionTurno turno = new AsignacionTurno();

        Integer idAcopioEsperado = 12;
        LocalDate fechaEsperada = LocalDate.of(2026, 10, 25);

        turno.setIdAcopio(idAcopioEsperado);
        turno.setFechaTurno(fechaEsperada);

        System.out.println("ID Acopio asignado: " + turno.getIdAcopio());
        System.out.println("Fecha de turno asignada: " + turno.getFechaTurno());

        assertEquals(idAcopioEsperado, turno.getIdAcopio());
        assertEquals(fechaEsperada, turno.getFechaTurno());
    }

    @Test
    void probarBloqueHorario() {
        AsignacionTurno turno = new AsignacionTurno();

        AsignacionTurno.BloqueHorario bloqueEsperado = AsignacionTurno.BloqueHorario.Noche;
        turno.setBloqueHorario(bloqueEsperado);

        System.out.println("Bloque horario asignado: " + turno.getBloqueHorario());

        assertEquals(bloqueEsperado, turno.getBloqueHorario());
    }
}
package com.donaton.inventario_service.service;

import com.donaton.inventario_service.model.InventarioStock;
import com.donaton.inventario_service.model.MovimientoInventario;
import com.donaton.inventario_service.repository.MovimientoInventarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class MovimientoInventarioService {


    @Autowired
    private MovimientoInventarioRepository movimientoInventarioRepository;

    public List<MovimientoInventario> getMovimientoInventarios() {
        return movimientoInventarioRepository.findAll();
    }

    public MovimientoInventario saveMovimientoInventario(MovimientoInventario movimientoInventario) {
        return movimientoInventarioRepository.save(movimientoInventario);
    }

    public Optional<MovimientoInventario> getMovimientoInventario(Integer id) {
        return movimientoInventarioRepository.findById(id);
    }

    public MovimientoInventario updateMovimientoInventario(MovimientoInventario movimientoInventario) {
        return movimientoInventarioRepository.save(movimientoInventario);
    }

    public void deleteMovimientoInventario(Integer id) {
        movimientoInventarioRepository.deleteById(id);
    }


}

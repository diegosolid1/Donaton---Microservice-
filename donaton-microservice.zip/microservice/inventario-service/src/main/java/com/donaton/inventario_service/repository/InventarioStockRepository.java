package com.donaton.inventario_service.repository;

import com.donaton.inventario_service.model.InventarioStock;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventarioStockRepository extends JpaRepository<InventarioStock, Integer> {
}

package com.donaton.inventario_service.repository;

import com.donaton.inventario_service.model.MovimientoInventario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovimientoInventarioRepository extends JpaRepository<MovimientoInventario, Integer> {


}

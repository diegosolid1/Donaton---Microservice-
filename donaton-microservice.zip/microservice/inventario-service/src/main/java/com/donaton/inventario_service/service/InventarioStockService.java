package com.donaton.inventario_service.service;

import com.donaton.inventario_service.model.InventarioStock;
import com.donaton.inventario_service.repository.InventarioStockRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class InventarioStockService {
    @Autowired
    private InventarioStockRepository inventarioStockRepository;

    public List<InventarioStock> getInventarioStocks() {
        return inventarioStockRepository.findAll();
    }

    public InventarioStock saveInventarioStock(InventarioStock inventarioStock) {
        return inventarioStockRepository.save(inventarioStock);
    }

    public Optional<InventarioStock> getInventarioStock(Integer id) {
        return inventarioStockRepository.findById(id);
    }

    public InventarioStock updateInventarioStock(InventarioStock inventarioStock) {
        return inventarioStockRepository.save(inventarioStock);
    }

    public void deleteInventarioStock(Integer id) {
        inventarioStockRepository.deleteById(id);
    }


}

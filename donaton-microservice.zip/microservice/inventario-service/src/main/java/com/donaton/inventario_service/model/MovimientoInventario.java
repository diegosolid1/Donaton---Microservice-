package com.donaton.inventario_service.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "movimientoinventario")
@NoArgsConstructor
@AllArgsConstructor
@Data

public class MovimientoInventario {
    public enum TipoMovimiento {
        Entrada_Donacion, Salida_Despacho, Ajuste_Merma
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;




    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_movimiento", nullable = false)
    private TipoMovimiento tipoMovimiento;

    @Column(name = "cantidad", nullable = false)
    private Integer cantidad;

    @Column(name = "fecha_movimiento", nullable = false)
    private LocalDateTime fechaMovimiento;


    @ManyToOne
    @JoinColumn(name = "id_stock")
    private InventarioStock inventarioStock;

}

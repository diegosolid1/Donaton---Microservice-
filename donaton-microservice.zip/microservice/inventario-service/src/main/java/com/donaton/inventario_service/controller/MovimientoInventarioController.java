package com.donaton.inventario_service.controller;

import com.donaton.inventario_service.model.MovimientoInventario;
import com.donaton.inventario_service.service.MovimientoInventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/movimiento-inventario")
@Tag(name = "Movimientos de Inventario", description = "Operaciones del historial y flujo de movimientos en almacén.")
public class MovimientoInventarioController {

    @Autowired
    private MovimientoInventarioService movimientoInventarioService;

    @Operation(summary = "Listar todos los movimientos de inventario.")
    @GetMapping
    public ResponseEntity<List<MovimientoInventario>> getMovimientoInventarios() {
        List<MovimientoInventario> lista = movimientoInventarioService.getMovimientoInventarios();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(lista); // 200
        }
    }

    @Operation(summary = "Obtener un movimiento de inventario por ID.")
    @GetMapping("/{id}")
   /*public ResponseEntity<MovimientoInventario> getMovimientoInventario(@PathVariable Integer id) {
        Optional<MovimientoInventario> movimientoInventario = movimientoInventarioService.getMovimientoInventario(id);

        if (movimientoInventario.isPresent()) {
            return ResponseEntity.ok(movimientoInventario.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<MovimientoInventario> getMovimientoInventario(@PathVariable Integer id) {

        MovimientoInventario movimientoInventario = movimientoInventarioService.getMovimientoInventario(id).orElseThrow();
        EntityModel<MovimientoInventario> model = EntityModel.of(movimientoInventario);

        model.add(
                linkTo(
                        methodOn(MovimientoInventarioController.class)
                                .getMovimientoInventario(id)).withSelfRel()
        );

        return model;
    }

    @Operation(summary = "Registrar un nuevo movimiento de inventario.")
    @PostMapping
    public ResponseEntity<MovimientoInventario> saveMovimientoInventario(@Valid @RequestBody MovimientoInventario movimientoInventario) {
        MovimientoInventario nuevoMovimiento = movimientoInventarioService.saveMovimientoInventario(movimientoInventario);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevoMovimiento);
    }

    @Operation(summary = "Actualizar un movimiento de inventario existente.")
    @PutMapping("/{id}")
    public ResponseEntity<MovimientoInventario> updateMovimientoInventario(@PathVariable Integer id, @Valid @RequestBody MovimientoInventario movimientoInventario) {
        Optional<MovimientoInventario> existe = movimientoInventarioService.getMovimientoInventario(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        movimientoInventario.setId(id); // Seteamos el ID correspondiente al MovimientoInventario
        MovimientoInventario movimientoInventarioActualizado = movimientoInventarioService.updateMovimientoInventario(movimientoInventario);
        return ResponseEntity.ok(movimientoInventarioActualizado); // 200
    }

    @Operation(summary = "Eliminar un movimiento de inventario por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInventarioStock(@PathVariable Integer id) {
        Optional<MovimientoInventario> existe = movimientoInventarioService.getMovimientoInventario(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            movimientoInventarioService.deleteMovimientoInventario(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
package com.donaton.inventario_service.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "inventariostock")
@NoArgsConstructor
@AllArgsConstructor
@Data
public class InventarioStock {
    public enum UnidadMedida {
        Unidades, Kilogramos, Litros, Cajas
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "id_acopio", nullable = false)
    private Integer idAcopio;

    @Column(name = "nombre_producto", nullable = false, length = 100)
    private String nombreProducto;

    @Column(name = "cantidad_disponible", nullable = false)
    private Integer cantidadDisponible;

    @Enumerated(EnumType.STRING)
    @Column(name = "unidad_medida", nullable = false)
    private UnidadMedida unidadMedida;

    //fk interna
    @JsonIgnore
    @OneToMany(mappedBy = "inventarioStock", cascade = CascadeType.ALL)
    private List<MovimientoInventario> movimientos;
}

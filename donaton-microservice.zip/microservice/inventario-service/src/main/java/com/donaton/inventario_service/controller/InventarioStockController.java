package com.donaton.inventario_service.controller;

import com.donaton.inventario_service.model.InventarioStock;
import com.donaton.inventario_service.service.InventarioStockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/inventarioStock")
@Tag(name = "Inventario", description = "Operaciones de gestión de inventario y stock.")
public class InventarioStockController {

    @Autowired
    private InventarioStockService inventarioStockService;

    @Operation(summary = "Listar todo el stock en inventario.")
    @GetMapping
    public ResponseEntity<List<InventarioStock>> getInventarioStock() {
        List<InventarioStock> lista = inventarioStockService.getInventarioStocks();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(lista); // 200
        }
    }

    @Operation(summary = "Obtener stock de inventario por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<InventarioStock> getInventarioStock(@PathVariable Integer id) {
        Optional<InventarioStock> inventarioStock = inventarioStockService.getInventarioStock(id);

        if (inventarioStock.isPresent()) {
            return ResponseEntity.ok(inventarioStock.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<InventarioStock> getInventarioStock(@PathVariable Integer id) {

        InventarioStock inventarioStock = inventarioStockService.getInventarioStock(id).orElseThrow();
        EntityModel<InventarioStock> model = EntityModel.of(inventarioStock);

        model.add(
                linkTo(
                        methodOn(InventarioStockController.class)
                                .getInventarioStock(id)).withSelfRel()
        );

        return model;
    }

    @Operation(summary = "Registrar nuevo stock en inventario.")
    @PostMapping
    public ResponseEntity<InventarioStock> saveInventarioStock(@Valid @RequestBody InventarioStock inventarioStock) {
        InventarioStock nuevoInventario = inventarioStockService.saveInventarioStock(inventarioStock);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevoInventario);
    }

    @Operation(summary = "Actualizar stock de inventario existente.")
    @PutMapping("/{id}")
    public ResponseEntity<InventarioStock> updateInventarioStock(@PathVariable Integer id, @Valid @RequestBody InventarioStock inventarioStock) {
        Optional<InventarioStock> existe = inventarioStockService.getInventarioStock(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        inventarioStock.setId(id); // Seteamos el ID correspondiente al InventarioStock
        InventarioStock inventarioActualizado = inventarioStockService.updateInventarioStock(inventarioStock);
        return ResponseEntity.ok(inventarioActualizado); // 200
    }

    @Operation(summary = "Eliminar stock de inventario por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInventarioStock(@PathVariable Integer id) {
        Optional<InventarioStock> existe = inventarioStockService.getInventarioStock(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }
        try {
            inventarioStockService.deleteInventarioStock(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
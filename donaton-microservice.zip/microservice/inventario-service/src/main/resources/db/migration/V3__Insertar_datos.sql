-- v3: Inserción de datos iniciales de inventario y movimientos

-- Insertar Productos en el Stock
-- (Se asume la generación automática de IDs: 1, 2, 3 y 4)
INSERT INTO `inventariostock` (`id_acopio`, `nombre_producto`, `cantidad_disponible`, `unidad_medida`) VALUES
                                                                                                           (1, 'Kits de Primeros Auxilios', 120, 'Unidades'),
                                                                                                           (1, 'Harina de Trigo', 500, 'Kilogramos'),
                                                                                                           (2, 'Agua Mineral 5L', 300, 'Litros'),
                                                                                                           (2, 'Cobijas y Mantas', 15, 'Cajas');

-- Insertar Movimientos de Inventario
-- (Vinculados al id_stock correspondiente)
INSERT INTO `movimientoinventario` (`id_stock`, `tipo_movimiento`, `cantidad`, `fecha_movimiento`) VALUES
-- Movimientos para 'Kits de Primeros Auxilios' (id_stock: 1)
(1, 'Entrada_Donacion', 150, '2026-05-24 09:00:00'),
(1, 'Salida_Despacho', 30, '2026-05-24 14:30:00'), -- Quedan 120

-- Movimientos para 'Harina de Trigo' (id_stock: 2)
(2, 'Entrada_Donacion', 500, '2026-05-24 10:15:00'),

-- Movimientos para 'Agua Mineral 5L' (id_stock: 3)
(3, 'Entrada_Donacion', 310, '2026-05-24 11:00:00'),
(3, 'Ajuste_Merma', 10, '2026-05-24 16:00:00'), -- Se rompieron envases, quedan 300

-- Movimientos para 'Cobijas y Mantas' (id_stock: 4)
(4, 'Entrada_Donacion', 15, '2026-05-24 11:45:00');

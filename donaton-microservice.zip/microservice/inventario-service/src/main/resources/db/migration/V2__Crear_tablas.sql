-- v2: Creación de tablas para la base de datos donaton_inventario

-- 1. Crear la tabla principal: inventariostock
CREATE TABLE `inventariostock` (
                                   `id` INT(11) NOT NULL AUTO_INCREMENT,
                                   `id_acopio` INT(11) NOT NULL, -- Relación lógica con la DB de centros de acopio
                                   `nombre_producto` VARCHAR(100) NOT NULL,
                                   `cantidad_disponible` INT(11) NOT NULL,
                                   `unidad_medida` ENUM('Unidades', 'Kilogramos', 'Litros', 'Cajas') NOT NULL,
                                   PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. Crear la tabla dependiente: movimientoinventario
CREATE TABLE `movimientoinventario` (
                                        `id` INT(11) NOT NULL AUTO_INCREMENT,
                                        `id_stock` INT(11) NOT NULL,
                                        `tipo_movimiento` ENUM('Entrada_Donacion', 'Salida_Despacho', 'Ajuste_Merma') NOT NULL,
                                        `cantidad` INT(11) NOT NULL,
                                        `fecha_movimiento` DATETIME NOT NULL,
                                        PRIMARY KEY (`id`),
                                        KEY `fk_movimiento_inventario_stock` (`id_stock`),
                                        CONSTRAINT `fk_movimiento_inventario_stock` FOREIGN KEY (`id_stock`) REFERENCES `inventariostock` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
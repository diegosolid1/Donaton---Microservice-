package com.donaton.inventario_service;

import com.donaton.inventario_service.model.InventarioStock;
import com.donaton.inventario_service.model.MovimientoInventario;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionInventarioTest {

    // ==========================================
    // TESTS DE INVENTARIO STOCK
    // ==========================================

    @Test
    void registrarInventarioStock() {
        InventarioStock stock = new InventarioStock();
        Faker faker = new Faker();

        stock.setId(faker.number().positive());
        stock.setIdAcopio(faker.number().positive());
        stock.setNombreProducto(faker.commerce().productName());
        stock.setCantidadDisponible(faker.number().numberBetween(10, 500));

        // Obtener una unidad de medida aleatoria del Enum
        InventarioStock.UnidadMedida[] unidades = InventarioStock.UnidadMedida.values();
        InventarioStock.UnidadMedida unidadAleatoria = unidades[faker.random().nextInt(unidades.length)];
        stock.setUnidadMedida(unidadAleatoria);

        System.out.println("ID Stock: " + stock.getId());
        System.out.println("ID Acopio: " + stock.getIdAcopio());
        System.out.println("Producto: " + stock.getNombreProducto());
        System.out.println("Cantidad Disponible: " + stock.getCantidadDisponible());
        System.out.println("Unidad de Medida: " + stock.getUnidadMedida());

        assertNotNull(stock);
        assertNotNull(stock.getNombreProducto());
        assertNotNull(stock.getUnidadMedida());
    }

    @Test
    void probarNombreYCantidadStock() {
        InventarioStock stock = new InventarioStock();

        String productoEsperado = "Mascarillas Quirúrgicas";
        Integer cantidadEsperada = 1500;

        stock.setNombreProducto(productoEsperado);
        stock.setCantidadDisponible(cantidadEsperada);

        System.out.println("Producto asignado: " + stock.getNombreProducto());
        System.out.println("Cantidad asignada: " + stock.getCantidadDisponible());

        assertEquals(productoEsperado, stock.getNombreProducto());
        assertEquals(cantidadEsperada, stock.getCantidadDisponible());
    }

    @Test
    void probarUnidadMedidaStock() {
        InventarioStock stock = new InventarioStock();

        InventarioStock.UnidadMedida unidadEsperada = InventarioStock.UnidadMedida.Cajas;
        stock.setUnidadMedida(unidadEsperada);

        System.out.println("Unidad de medida asignada: " + stock.getUnidadMedida());

        assertEquals(unidadEsperada, stock.getUnidadMedida());
    }

    // ==========================================
    // TESTS DE MOVIMIENTO DE INVENTARIO
    // ==========================================

    @Test
    void registrarMovimientoInventario() {
        MovimientoInventario movimiento = new MovimientoInventario();
        Faker faker = new Faker();

        movimiento.setId(faker.number().positive());
        movimiento.setCantidad(faker.number().numberBetween(1, 100));
        movimiento.setFechaMovimiento(LocalDateTime.now());

        // Obtener un tipo de movimiento aleatorio del Enum
        MovimientoInventario.TipoMovimiento[] tipos = MovimientoInventario.TipoMovimiento.values();
        MovimientoInventario.TipoMovimiento tipoAleatorio = tipos[faker.random().nextInt(tipos.length)];
        movimiento.setTipoMovimiento(tipoAleatorio);

        System.out.println("ID Movimiento: " + movimiento.getId());
        System.out.println("Tipo Movimiento: " + movimiento.getTipoMovimiento());
        System.out.println("Cantidad: " + movimiento.getCantidad());
        System.out.println("Fecha Movimiento: " + movimiento.getFechaMovimiento());

        assertNotNull(movimiento);
        assertNotNull(movimiento.getTipoMovimiento());
        assertNotNull(movimiento.getFechaMovimiento());
    }

    @Test
    void probarFechaYCantidadMovimiento() {
        MovimientoInventario movimiento = new MovimientoInventario();

        Integer cantidadEsperada = 25;
        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 6, 15, 10, 45);

        movimiento.setCantidad(cantidadEsperada);
        movimiento.setFechaMovimiento(fechaEsperada);

        System.out.println("Cantidad asignada: " + movimiento.getCantidad());
        System.out.println("Fecha asignada: " + movimiento.getFechaMovimiento());

        assertEquals(cantidadEsperada, movimiento.getCantidad());
        assertEquals(fechaEsperada, movimiento.getFechaMovimiento());
    }

    @Test
    void probarTipoMovimiento() {
        MovimientoInventario movimiento = new MovimientoInventario();

        MovimientoInventario.TipoMovimiento tipoEsperado = MovimientoInventario.TipoMovimiento.Salida_Despacho;
        movimiento.setTipoMovimiento(tipoEsperado);

        System.out.println("Tipo de movimiento asignado: " + movimiento.getTipoMovimiento());

        assertEquals(tipoEsperado, movimiento.getTipoMovimiento());
    }
}
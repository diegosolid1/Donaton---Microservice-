package com.donaton.centros_acopio_service;

import com.donaton.centros_acopio_service.model.CentroAcopio;
import com.donaton.centros_acopio_service.model.HorarioAcopio;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionCentrosAcopioTest {

    // ==========================================
    // TESTS DE CENTRO DE ACOPIO
    // ==========================================

    @Test
    void registrarCentroAcopio() {
        CentroAcopio centro = new CentroAcopio();
        Faker faker = new Faker();

        centro.setId(faker.number().positive());
        centro.setIdUsuarioEncargado(faker.number().positive());
        centro.setNombre("Centro de Ayuda " + faker.address().cityName());
        centro.setDireccion(faker.address().fullAddress());

        // Obtener un estado aleatorio del Enum EstadoCentro
        CentroAcopio.EstadoCentro[] estados = CentroAcopio.EstadoCentro.values();
        CentroAcopio.EstadoCentro estadoAleatorio = estados[faker.random().nextInt(estados.length)];
        centro.setEstadoCentro(estadoAleatorio);

        System.out.println("ID Centro: " + centro.getId());
        System.out.println("ID Encargado: " + centro.getIdUsuarioEncargado());
        System.out.println("Nombre Centro: " + centro.getNombre());
        System.out.println("Dirección: " + centro.getDireccion());
        System.out.println("Estado Centro: " + centro.getEstadoCentro());

        assertNotNull(centro);
        assertNotNull(centro.getEstadoCentro());
    }

    @Test
    void probarNombreYDireccionCentro() {
        CentroAcopio centro = new CentroAcopio();
        Faker faker = new Faker();

        String nombreEsperado = "Centro de Acopio Principal";
        String direccionEsperada = faker.address().fullAddress();

        centro.setNombre(nombreEsperado);
        centro.setDireccion(direccionEsperada);

        System.out.println("Nombre asignado: " + centro.getNombre());
        System.out.println("Dirección asignada: " + centro.getDireccion());

        assertEquals(nombreEsperado, centro.getNombre());
        assertEquals(direccionEsperada, centro.getDireccion());
    }

    @Test
    void probarEstadoCentro() {
        CentroAcopio centro = new CentroAcopio();

        CentroAcopio.EstadoCentro estadoEsperado = CentroAcopio.EstadoCentro.Disponible;
        centro.setEstadoCentro(estadoEsperado);

        System.out.println("Estado asignado: " + centro.getEstadoCentro());

        assertEquals(estadoEsperado, centro.getEstadoCentro());
    }

    // ==========================================
    // TESTS DE HORARIO DE ACOPIO
    // ==========================================

    @Test
    void registrarHorarioAcopio() {
        HorarioAcopio horario = new HorarioAcopio();
        Faker faker = new Faker();

        horario.setId(faker.number().positive());

        // Obtener un día aleatorio del Enum DiaSemana
        HorarioAcopio.DiaSemana[] dias = HorarioAcopio.DiaSemana.values();
        HorarioAcopio.DiaSemana diaAleatorio = dias[faker.random().nextInt(dias.length)];
        horario.setDiaSemana(diaAleatorio);

        // Definir objetos LocalTime fijos para la prueba base
        LocalTime apertura = LocalTime.of(9, 0);
        LocalTime cierre = LocalTime.of(18, 0);

        horario.setHoraApertura(apertura);
        horario.setHoraCierre(cierre);

        System.out.println("ID Horario: " + horario.getId());
        System.out.println("Día de la Semana: " + horario.getDiaSemana());
        System.out.println("Hora Apertura: " + horario.getHoraApertura());
        System.out.println("Hora Cierre: " + horario.getHoraCierre());

        assertNotNull(horario);
        assertNotNull(horario.getDiaSemana());
    }

    @Test
    void probarDiaSemana() {
        HorarioAcopio horario = new HorarioAcopio();

        HorarioAcopio.DiaSemana diaEsperado = HorarioAcopio.DiaSemana.Sabado;
        horario.setDiaSemana(diaEsperado);

        System.out.println("Día asignado: " + horario.getDiaSemana());

        assertEquals(diaEsperado, horario.getDiaSemana());
    }

    @Test
    void probarHorasAcopio() {
        HorarioAcopio horario = new HorarioAcopio();

        LocalTime aperturaEsperada = LocalTime.of(8, 30);
        LocalTime cierreEsperado = LocalTime.of(20, 0);

        horario.setHoraApertura(aperturaEsperada);
        horario.setHoraCierre(cierreEsperado);

        System.out.println("Hora apertura asignada: " + horario.getHoraApertura());
        System.out.println("Hora cierre asignada: " + horario.getHoraCierre());

        assertEquals(aperturaEsperada, horario.getHoraApertura());
        assertEquals(cierreEsperado, horario.getHoraCierre());
    }
}
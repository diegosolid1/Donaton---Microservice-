package com.donaton.centros_acopio_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CentrosAcopioServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

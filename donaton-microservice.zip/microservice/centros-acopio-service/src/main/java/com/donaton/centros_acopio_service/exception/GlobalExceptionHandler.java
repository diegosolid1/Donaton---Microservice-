package com.donaton.centros_acopio_service.exception; // Ajusta el package según dónde lo guardes

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> manejarValidaciones(MethodArgumentNotValidException ex) {
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("status", HttpStatus.BAD_REQUEST.value()); // 400
        errorBody.put("error", "Bad Request");
        errorBody.put("timestamp", LocalDateTime.now().toString());

        Map<String, String> detalesErrores = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            detalesErrores.put(fieldName, errorMessage);
        });

        errorBody.put("errors", detalesErrores);

        return new ResponseEntity<>(errorBody, HttpStatus.BAD_REQUEST);
    }

    // MANEJA EL ESTADO 500 - INTERNAL SERVER ERROR (Cualquier error inesperado en el backend o BD)
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> manejarErroresGlobales(Exception ex) {
        Map<String, Object> errorBody = new HashMap<>();
        errorBody.put("status", HttpStatus.INTERNAL_SERVER_ERROR.value()); // 500
        errorBody.put("error", "Internal Server Error");
        errorBody.put("message", "Ocurrió un error inesperado en el servidor. Inténtelo más tarde.");
        errorBody.put("timestamp", LocalDateTime.now().toString());

        return new ResponseEntity<>(errorBody, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
package com.donaton.centros_acopio_service.repository;

import com.donaton.centros_acopio_service.model.CentroAcopio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CentroAcopioRepository extends JpaRepository<CentroAcopio, Integer> {

}

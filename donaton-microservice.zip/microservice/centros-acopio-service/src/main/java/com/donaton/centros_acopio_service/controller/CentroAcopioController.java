package com.donaton.centros_acopio_service.controller;

import com.donaton.centros_acopio_service.model.CentroAcopio;
import com.donaton.centros_acopio_service.service.CentroAcopioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/centroacopio")
@Tag(name = "Centros de Acopio", description = "Operaciones relacionadas con la gestión de centros de acopio")
public class CentroAcopioController {

    @Autowired
    private CentroAcopioService centroAcopioService;

    @Operation(summary = "Obtener todos los centros de acopio")
    @GetMapping
    public ResponseEntity<List<CentroAcopio>> getCentrosAcopio() {
        List<CentroAcopio> lista = centroAcopioService.getCentrosAcopio();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204 No Content si la lista está vacía
        } else {
            return ResponseEntity.ok(lista); // 200 OK con la lista
        }
    }

    @Operation(summary = "Obtener un centro de acopio por su ID")
    @GetMapping("/{id}")
    /*public ResponseEntity<CentroAcopio> getCentroAcopio(@PathVariable Integer id) {
        Optional<CentroAcopio> centroAcopio = centroAcopioService.getCentroAcopio(id);

        if (centroAcopio.isPresent()) {
            return ResponseEntity.ok(centroAcopio.get()); // 200 OK con el objeto encontrado
        } else {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }
    } */
    public EntityModel<CentroAcopio> getCentroAcopio(@PathVariable Integer id) {

        CentroAcopio centroAcopio = centroAcopioService.getCentroAcopio(id).orElseThrow();
        EntityModel<CentroAcopio> model = EntityModel.of(centroAcopio);

        model.add(
                linkTo(
                        methodOn(CentroAcopioController.class)
                                .getCentroAcopio(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Crear un nuevo centro de acopio")
    @PostMapping
    public ResponseEntity<CentroAcopio> saveCentroAcopio(@Valid @RequestBody CentroAcopio centroAcopio) {
        CentroAcopio nuevoCentro = centroAcopioService.saveCentroAcopio(centroAcopio);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201 Created
                .body(nuevoCentro);
    }

    @Operation(summary = "Actualizar un centro de acopio existente")
    @PutMapping("/{id}")
    public ResponseEntity<CentroAcopio> updateCentroAcopio(@PathVariable Integer id, @Valid @RequestBody CentroAcopio centroAcopio) {
        Optional<CentroAcopio> existe = centroAcopioService.getCentroAcopio(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404 Not Found
        }

        centroAcopio.setId(id); // Seteamos el ID correspondiente al Centro de Acopio
        CentroAcopio centroActualizado = centroAcopioService.updateCentroAcopio(centroAcopio);
        return ResponseEntity.ok(centroActualizado); // 200 OK con el objeto actualizado
    }

    @Operation(summary = "Eliminar un centro de acopio por su ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCentroAcopio(@PathVariable Integer id) {
        try {
            centroAcopioService.deleteCentroAcopio(id);
            return ResponseEntity.noContent().build(); // 204 No Content en caso de éxito
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404 Not Found en caso de error
        }
    }
}
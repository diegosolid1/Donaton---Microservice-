package com.donaton.centros_acopio_service.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Table(name = "centroacopio")
@NoArgsConstructor
@AllArgsConstructor
@Data

public class CentroAcopio {

    public enum EstadoCentro {
        Disponible, Lleno, Inactivo
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "id_usuario_encargado")
    private Integer idUsuarioEncargado;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "direccion")
    private String direccion;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado_centro")
    private EstadoCentro estadoCentro;


    @JsonIgnore
    @OneToMany(mappedBy = "centroAcopio", cascade = CascadeType.ALL)
    private List<HorarioAcopio> horarios;



}

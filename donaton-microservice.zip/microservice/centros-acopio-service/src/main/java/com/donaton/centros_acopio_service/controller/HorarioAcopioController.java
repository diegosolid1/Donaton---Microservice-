package com.donaton.centros_acopio_service.controller;

import com.donaton.centros_acopio_service.model.HorarioAcopio;
import com.donaton.centros_acopio_service.service.HorarioAcopioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/horarioAcopio")
@Tag(name = "Horarios de Acopio", description = "Operaciones relacionadas con la gestión de horarios de acopio")
public class HorarioAcopioController {

    @Autowired
    private HorarioAcopioService horarioAcopioService;

    @Operation(summary = "Obtener todos los horarios de acopio")
    @GetMapping
    public ResponseEntity<List<HorarioAcopio>> getHorariosAcopio() {
        List<HorarioAcopio> lista = horarioAcopioService.getHorariosAcopio();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(lista); // 200
        }
    }

    @Operation(summary = "Obtener un horario de acopio por su ID")
    @GetMapping("/{id}")
    /*public ResponseEntity<HorarioAcopio> getHorarioAcopio(@PathVariable Integer id) {
        Optional<HorarioAcopio> horarioAcopio = horarioAcopioService.getHorarioAcopio(id);

        if (horarioAcopio.isPresent()) {
            return ResponseEntity.ok(horarioAcopio.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<HorarioAcopio> getHorarioAcopio(@PathVariable Integer id) {

        HorarioAcopio horarioAcopio = horarioAcopioService.getHorarioAcopio(id).orElseThrow();
        EntityModel<HorarioAcopio> model = EntityModel.of(horarioAcopio);

        model.add(
                linkTo(
                        methodOn(HorarioAcopioController.class)
                                .getHorarioAcopio(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Crear un nuevo horario de acopio")
    @PostMapping
    public ResponseEntity<HorarioAcopio> saveHorarioAcopio(@Valid @RequestBody HorarioAcopio horarioAcopio) {
        HorarioAcopio nuevoHorario = horarioAcopioService.saveHorarioAcopio(horarioAcopio);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevoHorario);
    }

    @Operation(summary = "Actualizar un horario de acopio existente")
    @PutMapping("/{id}")
    public ResponseEntity<HorarioAcopio> updateHorarioAcopio(@PathVariable Integer id, @Valid @RequestBody HorarioAcopio horarioAcopio) {
        Optional<HorarioAcopio> existe = horarioAcopioService.getHorarioAcopio(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        horarioAcopio.setId(id); // Seteamos el ID correspondiente al Horario de Acopio
        HorarioAcopio horarioActualizado = horarioAcopioService.updateHorarioAcopio(horarioAcopio);
        return ResponseEntity.ok(horarioActualizado); // 200
    }

    @Operation(summary = "Eliminar un horario de acopio por su ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteHorarioAcopio(@PathVariable Integer id) {
        try {
            horarioAcopioService.deleteHorarioAcopio(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
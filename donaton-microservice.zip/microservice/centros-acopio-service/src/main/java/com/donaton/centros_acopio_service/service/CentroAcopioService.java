package com.donaton.centros_acopio_service.service;

import com.donaton.centros_acopio_service.model.CentroAcopio;
import com.donaton.centros_acopio_service.repository.CentroAcopioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class CentroAcopioService {
    @Autowired
    private CentroAcopioRepository centroAcopioRepository;

    public List<CentroAcopio> getCentrosAcopio() {
        return centroAcopioRepository.findAll();
    }

    public CentroAcopio saveCentroAcopio(CentroAcopio centroAcopio) {
        return centroAcopioRepository.save(centroAcopio);
    }

    public Optional<CentroAcopio> getCentroAcopio(Integer id) {
        return centroAcopioRepository.findById(id);
    }

    public CentroAcopio updateCentroAcopio(CentroAcopio centroAcopio) {
        return centroAcopioRepository.save(centroAcopio);
    }

    public void deleteCentroAcopio(Integer id) {
        centroAcopioRepository.deleteById(id);
    }




}

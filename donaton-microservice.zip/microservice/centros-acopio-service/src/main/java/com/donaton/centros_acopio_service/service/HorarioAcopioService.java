package com.donaton.centros_acopio_service.service;

import com.donaton.centros_acopio_service.model.HorarioAcopio;
import com.donaton.centros_acopio_service.repository.HorarioAcopioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class HorarioAcopioService {

    @Autowired
    private HorarioAcopioRepository horarioAcopioRepository;

    public List<HorarioAcopio> getHorariosAcopio() {
        return horarioAcopioRepository.findAll();
    }

    public HorarioAcopio saveHorarioAcopio(HorarioAcopio horarioAcopio) {
        return horarioAcopioRepository.save(horarioAcopio);
    }

    public Optional<HorarioAcopio> getHorarioAcopio(Integer id) {
        return horarioAcopioRepository.findById(id);
    }

    public HorarioAcopio updateHorarioAcopio(HorarioAcopio horarioAcopio) {
        return horarioAcopioRepository.save(horarioAcopio);
    }

    public void deleteHorarioAcopio(Integer id) {
        horarioAcopioRepository.deleteById(id);
    }


}

package com.donaton.centros_acopio_service.repository;

import com.donaton.centros_acopio_service.model.HorarioAcopio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorarioAcopioRepository extends JpaRepository<HorarioAcopio, Integer> {

}

-- v2: Creación de tablas para la base de datos donaton_centros_acopio

-- 1. Crear la tabla principal: centroacopio
CREATE TABLE `centroacopio` (
                                `id` INT(11) NOT NULL AUTO_INCREMENT,
                                `id_usuario_encargado` INT(11) NOT NULL,
                                `nombre` VARCHAR(100) NOT NULL,
                                `direccion` VARCHAR(255) NOT NULL,
                                `estado_centro` ENUM('Disponible', 'Lleno', 'Inactivo') NOT NULL,
                                PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. Crear la tabla dependiente: horarioacopio
CREATE TABLE `horarioacopio` (
                                 `id` INT(11) NOT NULL AUTO_INCREMENT,
                                 `id_acopio` INT(11) NOT NULL,
                                 `dia_semana` ENUM('Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo') NOT NULL,
                                 `hora_apertura` TIME NOT NULL,
                                 `hora_cierre` TIME NOT NULL,
                                 PRIMARY KEY (`id`),
                                 KEY `fk_horario_centro_acopio` (`id_acopio`),
                                 CONSTRAINT `fk_horario_centro_acopio` FOREIGN KEY (`id_acopio`) REFERENCES `centroacopio` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
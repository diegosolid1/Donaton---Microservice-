-- v3: Inserción de datos iniciales

-- Insertar Centros de Acopio
INSERT INTO `centroacopio` (`id_usuario_encargado`, `nombre`, `direccion`, `estado_centro`) VALUES
                                                                                                (101, 'Centro de Acopio Central', 'Av. Principal 123, Sector Centro', 'Disponible'),
                                                                                                (102, 'Bodega de Ayuda Sur', 'Calle Secundaria 456, Barrio Sur', 'Disponible'),
                                                                                                (103, 'Punto de Recolección Norte', 'Km 5 Vía del Norte', 'Lleno');

-- Insertar Horarios de Acopio
-- (Asumiendo que los IDs auto-incrementales generados para los centros son 1, 2 y 3)
INSERT INTO `horarioacopio` (`id_acopio`, `dia_semana`, `hora_apertura`, `hora_cierre`) VALUES
-- Horarios para el Centro Central (ID: 1)
(1, 'Lunes', '08:00:00', '17:00:00'),
(1, 'Miercoles', '08:00:00', '17:00:00'),
(1, 'Viernes', '08:00:00', '17:00:00'),

-- Horarios para la Bodega Sur (ID: 2)
(2, 'Martes', '09:00:00', '18:00:00'),
(2, 'Jueves', '09:00:00', '18:00:00'),
(2, 'Sabado', '09:00:00', '14:00:00'),

-- Horarios para el Punto Norte (ID: 3)
(3, 'Domingo', '10:00:00', '14:00:00');

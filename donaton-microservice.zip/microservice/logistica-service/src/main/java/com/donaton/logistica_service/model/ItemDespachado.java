package com.donaton.logistica_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "itemdespachado")
public class ItemDespachado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_item_despachado")
    private Integer idItemDespachado;

    @NotNull(message = "El ID del despacho es obligatorio")
    @Positive(message = "El ID del despacho debe ser un número positivo")
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "id_despacho")
    private Despacho despacho;

    @NotBlank(message = "El nombre del producto es obligatorio")
    @Size(max = 100, message = "El nombre del producto no puede superar los 100 caracteres")
    @Column(name = "nombre_producto")
    private String nombreProducto;

    @NotNull(message = "La cantidad es obligatoria")
    @Positive(message = "La cantidad debe ser un número positivo mayor a cero")
    @Column(name = "cantidad")
    private Integer cantidad;
}
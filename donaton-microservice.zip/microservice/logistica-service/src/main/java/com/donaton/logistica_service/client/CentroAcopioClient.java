package com.donaton.logistica_service.client;

import com.donaton.logistica_service.dto.CentroAcopioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class CentroAcopioClient {
    @Autowired
    private WebClient webClient;

    public List<CentroAcopioDTO> obtenerCentrosAcopio() {
        return webClient
                .get()
                .uri("/api/v1/centroacopio") // Ajustá la ruta exacta de tu API si cambia
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<CentroAcopioDTO>>() {})
                .block();
    }
}
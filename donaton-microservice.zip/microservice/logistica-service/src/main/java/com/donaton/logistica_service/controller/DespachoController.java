package com.donaton.logistica_service.controller;

import com.donaton.logistica_service.dto.CentroAcopioDTO;
import com.donaton.logistica_service.dto.ZonaAfectadaDTO;
import com.donaton.logistica_service.model.Despacho;
import com.donaton.logistica_service.service.DespachoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/despacho")
@Tag(name = "Despachos", description = "Operaciones de gestión y distribución de despachos.")
public class DespachoController {

    @Autowired
    private DespachoService despachoService;

    @Operation(summary = "Listar todos los despachos.")
    @GetMapping
    public ResponseEntity<List<Despacho>> listarDespachos() {
        List<Despacho> despachos = despachoService.getDespachos();

        if (despachos.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(despachos); // 200
        }
    }

    @Operation(summary = "Obtener un despacho por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<Despacho> buscarPorId(@PathVariable Integer id) {
        Optional<Despacho> despacho = despachoService.getDespacho(id);

        if (despacho.isPresent()) {
            return ResponseEntity.ok(despacho.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<Despacho> getDespacho(@PathVariable Integer id) {

        Despacho despacho = despachoService.getDespacho(id).orElseThrow();
        EntityModel<Despacho> model = EntityModel.of(despacho);

        model.add(
                linkTo(
                        methodOn(DespachoController.class)
                                .getDespacho(id)).withSelfRel()
        );
        return model;
    }

    // 201 Created (o 400 Bad Request manejado por @ExceptionHandler)
    @Operation(summary = "Registrar un nuevo despacho.")
    @PostMapping
    public ResponseEntity<Despacho> agregarDespacho(@Valid @RequestBody Despacho despacho) {
        try {
            Despacho nuevoDespacho = despachoService.saveDespacho(despacho);
            return ResponseEntity
                    .status(HttpStatus.CREATED) // 201
                    .body(nuevoDespacho);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }

    @Operation(summary = "Actualizar un despacho existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Despacho> editarDespacho(@Valid @RequestBody Despacho despacho, @PathVariable Integer id) {
        Optional<Despacho> existe = despachoService.getDespacho(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        despacho.setIdDespacho(id);

        try {
            Despacho actualizado = despachoService.saveDespacho(despacho);
            return ResponseEntity.ok(actualizado); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }

    // 204 No Content o 404 Not Found
    @Operation(summary = "Eliminar un despacho por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDespacho(@PathVariable Integer id) {
        try {
            despachoService.deleteDespacho(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }

    @Operation(summary = "Listar centros de acopio disponibles.")
    @GetMapping("/centroacopio")
    public ResponseEntity<List<CentroAcopioDTO>> listarCentrosAcopio() {
        List<CentroAcopioDTO> centros = despachoService.listarCentrosDeAcopio();

        if (centros.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(centros); // 200
        }
    }

    @Operation(summary = "Listar zonas afectadas asociadas.")
    @GetMapping("/zona")
    public ResponseEntity<List<ZonaAfectadaDTO>> listarZonasAfectadas() {
        List<ZonaAfectadaDTO> zonas = despachoService.listarZonasAfectadas();

        if (zonas.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(zonas); // 200
        }
    }
}
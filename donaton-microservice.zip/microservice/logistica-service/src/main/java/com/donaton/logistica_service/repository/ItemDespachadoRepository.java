package com.donaton.logistica_service.repository;

import com.donaton.logistica_service.model.ItemDespachado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemDespachadoRepository extends JpaRepository<ItemDespachado, Integer> {
}
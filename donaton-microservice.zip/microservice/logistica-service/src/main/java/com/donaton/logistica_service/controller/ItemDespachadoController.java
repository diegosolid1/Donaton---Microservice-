package com.donaton.logistica_service.controller;

import com.donaton.logistica_service.model.ItemDespachado;
import com.donaton.logistica_service.service.ItemDespachadoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/item-despachado")
@Tag(name = "Ítems Despachados", description = "Operaciones de control de los ítems incluidos en los despachos.")
public class ItemDespachadoController {

    @Autowired
    private ItemDespachadoService itemDespachadoService;

    // 200 OK o 204 No Content
    @Operation(summary = "Listar todos los ítems despachados.")
    @GetMapping
    public ResponseEntity<List<ItemDespachado>> listarItems() {
        List<ItemDespachado> items = itemDespachadoService.getItemsDespachados();
        if (items.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(items); // 200
        }
    }

    // 200 OK o 404 Not Found
    @Operation(summary = "Obtener un ítem despachado por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<ItemDespachado> buscarPorId(@PathVariable Integer id) {
        Optional<ItemDespachado> item = itemDespachadoService.getItemDespachado(id);
        if (item.isPresent()) {
            return ResponseEntity.ok(item.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    }  */
    public EntityModel<ItemDespachado> getItemDespachado(@PathVariable Integer id) {

        ItemDespachado itemDespachado = itemDespachadoService.getItemDespachado(id).orElseThrow();
        EntityModel<ItemDespachado> model = EntityModel.of(itemDespachado);

        model.add(
                linkTo(
                        methodOn(ItemDespachadoController.class)
                                .getItemDespachado(id)).withSelfRel()
        );

        return model;
    }

    // 201 Created o 500 Internal Server Error
    @Operation(summary = "Registrar un nuevo ítem despachado.")
    @PostMapping
    public ResponseEntity<ItemDespachado> agregarItem(@Valid @RequestBody ItemDespachado itemDespachado) {
        try {
            ItemDespachado nuevoItem = itemDespachadoService.saveItemDespachado(itemDespachado);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoItem); // 201
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }

    // 200 OK o 404 Not Found
    @Operation(summary = "Actualizar un ítem despachado existente.")
    @PutMapping("/{id}")
    public ResponseEntity<ItemDespachado> editarItem(@Valid @RequestBody ItemDespachado itemDespachado, @PathVariable Integer id) {
        Optional<ItemDespachado> existe = itemDespachadoService.getItemDespachado(id);
        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        itemDespachado.setIdItemDespachado(id);
        try {
            ItemDespachado actualizado = itemDespachadoService.saveItemDespachado(itemDespachado);
            return ResponseEntity.ok(actualizado); // 200
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }

    // 204 No Content o 404 Not Found
    @Operation(summary = "Eliminar un ítem despachado por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarItem(@PathVariable Integer id) {
        try {
            itemDespachadoService.deleteItemDespachado(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build(); // 404
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // 500
        }
    }
}
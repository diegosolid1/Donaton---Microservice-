package com.donaton.logistica_service.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient webClient(WebClient.Builder builder) {
        // Apunta directamente a la URL base del microservicio de Centros de Acopio
        return builder
                .baseUrl("http://localhost:8091")
                .build();
    }


    @Bean(name = "zonasWebClient")
    public WebClient zonasWebClient(WebClient.Builder builder) {

        return builder
                .baseUrl("http://localhost:8084")
                .build();
    }
}
package com.donaton.logistica_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "despacho") // Asumiendo el nombre lógico de la tabla por sus campos
public class Despacho {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_despacho")
    private Integer idDespacho;

    @NotNull(message = "El ID de acopio de origen es obligatorio")
    @Positive(message = "El ID de acopio de origen debe ser un número positivo")
    @Column(name = "id_acopio_origen")
    private Integer idAcopioOrigen;

    @NotNull(message = "El ID de la zona de destino es obligatorio")
    @Positive(message = "El ID de la zona de destino debe ser un número positivo")
    @Column(name = "id_zona_destino")
    private Integer idZonaDestino;

    @NotNull(message = "La fecha de salida es obligatoria")
    @Column(name = "fecha_salida")
    private LocalDateTime fechaSalida;

    @NotNull(message = "El estado del despacho es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "estado_despacho", columnDefinition = "ENUM('Preparacion', 'En_Ruta', 'Entregado', 'Cancelado')")
    private EstadoDespacho estadoDespacho;

    public enum EstadoDespacho {
        Preparacion,
        En_Ruta,
        Entregado,
        Cancelado
    }

    @JsonIgnore
    @OneToMany(mappedBy = "despacho", cascade = CascadeType.ALL)
    private List<ItemDespachado> items;
}

package com.donaton.logistica_service.client;

import com.donaton.logistica_service.dto.ZonaAfectadaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class ZonaAfectadaClient {
    @Autowired
    @Qualifier("zonasWebClient")
    private  WebClient zonasWebClient;

    public List<ZonaAfectadaDTO> obtenerZonasAfectadas() {
        return zonasWebClient
                .get()
                .uri("/api/v1/zona")
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<ZonaAfectadaDTO>>() {})
                .block(); // Mantenemos el .block() para que se acople fácil a tu DespachoService
    }
}
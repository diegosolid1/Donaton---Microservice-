package com.donaton.logistica_service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ZonaAfectadaDTO {

    private Integer id;
    private String comunaCiudad;
    @JsonProperty("id_emergencia")
    private Integer idEmergencia;

    @JsonProperty("nivel_gravedad")
    private String nivelGravedad;

    @JsonProperty("nombre_emergencia")
    private String nombreEmergencia;
}

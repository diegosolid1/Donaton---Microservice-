package com.donaton.logistica_service.service;

import com.donaton.logistica_service.model.ItemDespachado;
import com.donaton.logistica_service.repository.ItemDespachadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemDespachadoService {

    @Autowired
    private ItemDespachadoRepository itemDespachadoRepository;

    public List<ItemDespachado> getItemsDespachados() {
        return itemDespachadoRepository.findAll();
    }

    public Optional<ItemDespachado> getItemDespachado(Integer id) {
        return itemDespachadoRepository.findById(id);
    }

    public ItemDespachado saveItemDespachado(ItemDespachado itemDespachado) {
        return itemDespachadoRepository.save(itemDespachado);
    }

    public ItemDespachado updateItemDespachado(Integer id, ItemDespachado itemDespachado) {
        Optional<ItemDespachado> existe = getItemDespachado(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Item despachado no encontrado con el ID: " + id);
        } else {
            itemDespachado.setIdItemDespachado(id);
            return itemDespachadoRepository.save(itemDespachado);
        }
    }

    public void deleteItemDespachado(Integer id) {
        if (itemDespachadoRepository.existsById(id)) {
            itemDespachadoRepository.deleteById(id);
        } else {
            throw new RuntimeException("Item despachado no encontrado con el ID: " + id);
        }
    }
}
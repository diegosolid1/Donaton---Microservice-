package com.donaton.logistica_service.service;

import com.donaton.logistica_service.client.CentroAcopioClient;
import com.donaton.logistica_service.client.ZonaAfectadaClient;
import com.donaton.logistica_service.dto.CentroAcopioDTO;
import com.donaton.logistica_service.dto.ZonaAfectadaDTO;
import com.donaton.logistica_service.model.Despacho;
import com.donaton.logistica_service.repository.DespachoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DespachoService {

    @Autowired
    private DespachoRepository despachoRepository;

    @Autowired
    private CentroAcopioClient centroAcopioClient;

    @Autowired
    private ZonaAfectadaClient zonaAfectadaClient;

    // Obtener todos los despachos
    public List<Despacho> getDespachos() {
        return despachoRepository.findAll();
    }

    // Obtener un despacho por su ID
    public Optional<Despacho> getDespacho(Integer id) {
        return despachoRepository.findById(id);
    }

    // Guardar o crear un nuevo despacho
    public Despacho saveDespacho(Despacho despacho) {
        return despachoRepository.save(despacho);
    }

    // Actualizar un despacho existente
    public Despacho updateDespacho(Integer id, Despacho despacho) {
        Optional<Despacho> existe = getDespacho(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Despacho no encontrado con el ID: " + id);
        } else {
            // Aseguramos que se actualice el ID correcto que viene por parámetro
            despacho.setIdDespacho(id);
            return despachoRepository.save(despacho);
        }
    }

    // Eliminar un despacho por ID
    public void deleteDespacho(Integer id) {
        if (despachoRepository.existsById(id)) {
            despachoRepository.deleteById(id);
        } else {
            throw new RuntimeException("Despacho no encontrado con el ID: " + id);
        }
    }

    public List<CentroAcopioDTO> listarCentrosDeAcopio() {
        return centroAcopioClient.obtenerCentrosAcopio();
    }

    public List<ZonaAfectadaDTO> listarZonasAfectadas() {
        return zonaAfectadaClient.obtenerZonasAfectadas();
    }





}
package com.donaton.logistica_service.dto;

import lombok.Data;

@Data
public class CentroAcopioDTO {
    private Long idAcopio;
    private String nombre;
    private String direccion;
    private String telefono;

}

-- Volcado de datos para la tabla despacho
INSERT INTO `despacho` (`id_despacho`, `id_acopio_origen`, `id_zona_destino`, `fecha_salida`, `estado_despacho`) VALUES
                                                                                                                     (1, 101, 501, '2026-05-20 08:00:00', 'Entregado'),
                                                                                                                     (2, 101, 502, '2026-05-21 09:30:00', 'En_Ruta'),
                                                                                                                     (3, 102, 501, '2026-05-21 14:00:00', 'Preparacion'),
                                                                                                                     (4, 103, 503, '2026-05-19 10:00:00', 'Entregado'),
                                                                                                                     (5, 104, 504, '2026-05-22 07:00:00', 'Preparacion'),
                                                                                                                     (6, 102, 505, '2026-05-20 11:15:00', 'Cancelado'),
                                                                                                                     (7, 105, 502, '2026-05-21 16:45:00', 'En_Ruta'),
                                                                                                                     (8, 101, 503, '2026-05-18 12:00:00', 'Entregado'),
                                                                                                                     (9, 103, 501, '2026-05-22 10:30:00', 'Preparacion'),
                                                                                                                     (10, 105, 504, '2026-05-21 18:00:00', 'En_Ruta');

-- Volcado de datos para la tabla itemdespachado
INSERT INTO `itemdespachado` (`id_item_despachado`, `id_despacho`, `nombre_producto`, `cantidad`) VALUES
                                                                                                      (1, 1, 'Agua Embotellada 1L', 500),
                                                                                                      (2, 1, 'Enlatados de Atún', 300),
                                                                                                      (3, 2, 'Kits de Primeros Auxilios', 50),
                                                                                                      (4, 3, 'Cobijas y Mantas térmica', 200),
                                                                                                      (5, 4, 'Carpas para 4 personas', 40),
                                                                                                      (6, 5, 'Arroz (Sacos de 5kg)', 100),
                                                                                                      (7, 7, 'Leche en Polvo', 150),
                                                                                                      (8, 8, 'Herramientas de Rescate (Palas/Picos)', 20),
                                                                                                      (9, 9, 'Pañales para Bebé', 250),
                                                                                                      (10, 10, 'Linternas LED con Baterías', 120);
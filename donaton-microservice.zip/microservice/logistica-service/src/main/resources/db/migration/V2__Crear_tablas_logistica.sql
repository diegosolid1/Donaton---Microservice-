-- Estructura de tabla para la tabla despacho
CREATE TABLE `despacho` (
                            `id_despacho` int(11) NOT NULL AUTO_INCREMENT,
                            `id_acopio_origen` int(11) NOT NULL,
                            `id_zona_destino` int(11) NOT NULL,
                            `fecha_salida` datetime NOT NULL,
                            `estado_despacho` enum('Preparacion','En_Ruta','Entregado','Cancelado') NOT NULL,
                            PRIMARY KEY (`id_despacho`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Estructura de tabla para la tabla itemdespachado
CREATE TABLE `itemdespachado` (
                                  `id_item_despachado` int(11) NOT NULL AUTO_INCREMENT,
                                  `id_despacho` int(11) NOT NULL,
                                  `nombre_producto` varchar(100) NOT NULL,
                                  `cantidad` int(11) NOT NULL,
                                  PRIMARY KEY (`id_item_despachado`),
                                  CONSTRAINT `fk_item_despacho` FOREIGN KEY (`id_despacho`) REFERENCES `despacho` (`id_despacho`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
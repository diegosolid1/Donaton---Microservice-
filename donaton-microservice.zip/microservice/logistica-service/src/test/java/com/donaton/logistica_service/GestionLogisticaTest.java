package com.donaton.logistica_service;

import com.donaton.logistica_service.model.Despacho;
import com.donaton.logistica_service.model.ItemDespachado;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionLogisticaTest {

    // ==========================================
    // TESTS DE DESPACHO
    // ==========================================

    @Test
    void registrarDespacho() {
        Despacho despacho = new Despacho();
        Faker faker = new Faker();

        despacho.setIdDespacho(faker.number().positive());
        despacho.setIdAcopioOrigen(faker.number().positive());
        despacho.setIdZonaDestino(faker.number().positive());
        despacho.setFechaSalida(LocalDateTime.now());

        // Obtener un estado aleatorio del Enum EstadoDespacho
        Despacho.EstadoDespacho[] estados = Despacho.EstadoDespacho.values();
        Despacho.EstadoDespacho estadoAleatorio = estados[faker.random().nextInt(estados.length)];
        despacho.setEstadoDespacho(estadoAleatorio);

        System.out.println("ID Despacho: " + despacho.getIdDespacho());
        System.out.println("ID Acopio Origen: " + despacho.getIdAcopioOrigen());
        System.out.println("ID Zona Destino: " + despacho.getIdZonaDestino());
        System.out.println("Fecha Salida: " + despacho.getFechaSalida());
        System.out.println("Estado Despacho: " + despacho.getEstadoDespacho());

        assertNotNull(despacho);
        assertNotNull(despacho.getEstadoDespacho());
        assertNotNull(despacho.getFechaSalida());
    }

    @Test
    void probarIdsYFechaDespacho() {
        Despacho despacho = new Despacho();

        Integer idOrigenEsperado = 5;
        Integer idDestinoEsperado = 12;
        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 7, 20, 15, 30);

        despacho.setIdAcopioOrigen(idOrigenEsperado);
        despacho.setIdZonaDestino(idDestinoEsperado);
        despacho.setFechaSalida(fechaEsperada);

        System.out.println("ID Origen asignado: " + despacho.getIdAcopioOrigen());
        System.out.println("ID Destino asignado: " + despacho.getIdZonaDestino());
        System.out.println("Fecha Salida asignada: " + despacho.getFechaSalida());

        assertEquals(idOrigenEsperado, despacho.getIdAcopioOrigen());
        assertEquals(idDestinoEsperado, despacho.getIdZonaDestino());
        assertEquals(fechaEsperada, despacho.getFechaSalida());
    }

    @Test
    void probarEstadoDespacho() {
        Despacho despacho = new Despacho();

        Despacho.EstadoDespacho estadoEsperado = Despacho.EstadoDespacho.En_Ruta;
        despacho.setEstadoDespacho(estadoEsperado);

        System.out.println("Estado de despacho asignado: " + despacho.getEstadoDespacho());

        assertEquals(estadoEsperado, despacho.getEstadoDespacho());
    }

    // ==========================================
    // TESTS DE ITEM DESPACHADO
    // ==========================================

    @Test
    void registrarItemDespachado() {
        ItemDespachado item = new ItemDespachado();
        Faker faker = new Faker();

        item.setIdItemDespachado(faker.number().positive());
        item.setNombreProducto(faker.commerce().productName());
        item.setCantidad(faker.number().numberBetween(1, 200));

        System.out.println("ID Item Despachado: " + item.getIdItemDespachado());
        System.out.println("Nombre Producto: " + item.getNombreProducto());
        System.out.println("Cantidad: " + item.getCantidad());

        assertNotNull(item);
        assertNotNull(item.getNombreProducto());
    }

    @Test
    void probarNombreYCantidadItem() {
        ItemDespachado item = new ItemDespachado();

        String nombreEsperado = "Frazadas de Invierno";
        Integer cantidadEsperada = 40;

        item.setNombreProducto(nombreEsperado);
        item.setCantidad(cantidadEsperada);

        System.out.println("Nombre asignado: " + item.getNombreProducto());
        System.out.println("Cantidad asignada: " + item.getCantidad());

        assertEquals(nombreEsperado, item.getNombreProducto());
        assertEquals(cantidadEsperada, item.getCantidad());
    }
}
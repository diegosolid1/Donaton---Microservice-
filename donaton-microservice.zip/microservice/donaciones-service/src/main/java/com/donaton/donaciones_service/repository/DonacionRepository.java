package com.donaton.donaciones_service.repository;


import com.donaton.donaciones_service.model.Donacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DonacionRepository extends JpaRepository<Donacion, Integer> {


}

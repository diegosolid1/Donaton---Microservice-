package com.donaton.donaciones_service.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "itemdonado")
@Data
@NoArgsConstructor
@AllArgsConstructor

public class ItemDonado {


    public enum UnidadMedida {
        Unidades,
        Kilogramos,
        Litros
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "descripcion_producto", nullable = false, length = 100)
    private String descripcionProducto;

    @Column(name = "cantidad", nullable = false)
    private Integer cantidad;

    @Enumerated(EnumType.STRING)
    @Column(name = "unidad_medida", nullable = false)
    private UnidadMedida unidadMedida;



    @ManyToOne
    @JoinColumn(name = "donacion_id")
    private Donacion donacion;

}

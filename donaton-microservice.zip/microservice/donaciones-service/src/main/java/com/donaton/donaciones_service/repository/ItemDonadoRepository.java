package com.donaton.donaciones_service.repository;

import com.donaton.donaciones_service.model.ItemDonado;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ItemDonadoRepository extends JpaRepository<ItemDonado, Integer> {

}

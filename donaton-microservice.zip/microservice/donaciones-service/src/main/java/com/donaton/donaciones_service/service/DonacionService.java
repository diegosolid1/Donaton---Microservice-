package com.donaton.donaciones_service.service;

import com.donaton.donaciones_service.client.AutenticacionClient;
import com.donaton.donaciones_service.client.EmergenciaClient;
import com.donaton.donaciones_service.dto.EmergenciaDTO;
import com.donaton.donaciones_service.dto.UsuarioDTO;
import com.donaton.donaciones_service.model.Donacion;
import com.donaton.donaciones_service.repository.DonacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class DonacionService {

    @Autowired
    private DonacionRepository donacionRepository;

    @Autowired
    private AutenticacionClient autenticacionClient;

    @Autowired
    private EmergenciaClient emergenciaClient;

    public List<Donacion> getDonaciones() {
        return donacionRepository.findAll();
    }

    public Donacion saveDonacion(Donacion donacion) {
        return donacionRepository.save(donacion);
    }

    public Optional<Donacion> getDonacion(Integer id) {
        return donacionRepository.findById(id);
    }

    public Donacion updateDonacion(Donacion curso) {
        return donacionRepository.save(curso);
    }

    public void deleteDonacion(Integer id) {
        donacionRepository.deleteById(id);
    }

    public List<UsuarioDTO> obtenerUsuariosExternos() {
        return autenticacionClient.obtenerUsuarios();
    }

    public List<EmergenciaDTO> obtenerEmergenciasExternos() {
        return emergenciaClient.obtenerEmergencias();
    }
}

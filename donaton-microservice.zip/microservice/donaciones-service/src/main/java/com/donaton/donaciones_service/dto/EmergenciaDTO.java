package com.donaton.donaciones_service.dto;

import lombok.Data;

@Data
public class EmergenciaDTO {
    private Integer id;
    private String nombre;
    private String tipoEmergencia; // Pasado a String para evitar problemas de serialización del Enum
    private String estado;
}

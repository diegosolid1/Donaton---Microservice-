package com.donaton.donaciones_service.service;

import com.donaton.donaciones_service.model.ItemDonado;
import com.donaton.donaciones_service.repository.ItemDonadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ItemDonadoService {
    @Autowired
    private ItemDonadoRepository itemDonadoRepository;

    public List<ItemDonado> getItemDonados() {
        return itemDonadoRepository.findAll();
    }

    public ItemDonado saveItemDonado(ItemDonado item) {
        return itemDonadoRepository.save(item);
    }

    public Optional<ItemDonado> getItemDonado(Integer id) {
        return itemDonadoRepository.findById(id);
    }

    public ItemDonado updateItemDonado(ItemDonado item) {
        return itemDonadoRepository.save(item);
    }

    public void deleteItemDonado(Integer id) {
        itemDonadoRepository.deleteById(id);
    }

}

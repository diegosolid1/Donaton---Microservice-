package com.donaton.donaciones_service.client;


import com.donaton.donaciones_service.dto.UsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class AutenticacionClient {
    @Autowired
    private  WebClient webClient;

    public List<UsuarioDTO> obtenerUsuarios() {
        return webClient
                .get()
                .uri("/api/v1/usuario") // Ajusta el endpoint según tu Controller en Auth
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<UsuarioDTO>>() {})
                .block();
    }
}
package com.donaton.donaciones_service.controller;

import com.donaton.donaciones_service.model.ItemDonado;
import com.donaton.donaciones_service.service.ItemDonadoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/api/v1/itemsDonados")

@Tag(name = "Ítems Donados", description = "Operaciones de gestión de ítems donados.")
public class ItemDonadoController {

    @Autowired
    private ItemDonadoService itemDonadoService;

    @Operation(summary = "Listar todos los ítems donados.")
    @GetMapping
    public ResponseEntity<List<ItemDonado>> getItemDonados() {
        List<ItemDonado> lista = itemDonadoService.getItemDonados();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(lista); // 200
        }
    }

    @Operation(summary = "Obtener un ítem donado por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<ItemDonado> getItemDonado(@PathVariable Integer id) {
        Optional<ItemDonado> itemDonado = itemDonadoService.getItemDonado(id);

        if (itemDonado.isPresent()) {
            return ResponseEntity.ok(itemDonado.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<ItemDonado> getItemDonado(@PathVariable Integer id) {

        ItemDonado itemDonado = itemDonadoService.getItemDonado(id).orElseThrow();
        EntityModel<ItemDonado> model = EntityModel.of(itemDonado);

        model.add(
                linkTo(
                        methodOn(ItemDonadoController.class)
                                .getItemDonado(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar un nuevo ítem donado.")
    @PostMapping
    public ResponseEntity<ItemDonado> saveItemDonado(@Valid @RequestBody ItemDonado itemDonado) {
        ItemDonado nuevoItem = itemDonadoService.saveItemDonado(itemDonado);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevoItem);
    }

    @Operation(summary = "Actualizar un ítem donado existente.")
    @PutMapping("/{id}")
    public ResponseEntity<ItemDonado> updateItemDonado(@PathVariable Integer id, @Valid @RequestBody ItemDonado itemDonado) {
        Optional<ItemDonado> existe = itemDonadoService.getItemDonado(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        itemDonado.setId(id); // Seteamos el ID correspondiente al Item Donado
        ItemDonado actualizado = itemDonadoService.updateItemDonado(itemDonado);
        return ResponseEntity.ok(actualizado); // 200
    }

    @Operation(summary = "Eliminar un ítem donado por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDonacion(@PathVariable Integer id) {
        Optional<ItemDonado> existe = itemDonadoService.getItemDonado(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            itemDonadoService.deleteItemDonado(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
package com.donaton.donaciones_service.dto;

import lombok.Data;

@Data
public class RolDTO {
    private Integer id;
    private String nombreRol;
}

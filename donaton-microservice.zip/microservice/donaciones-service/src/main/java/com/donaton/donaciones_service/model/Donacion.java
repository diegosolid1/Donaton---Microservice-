package com.donaton.donaciones_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "donacion")
@NoArgsConstructor
@AllArgsConstructor
@Data


public class Donacion {

    public enum FormaEntrega {
        Monetaria,
        Insumos_Presencial,
        Insumos_Envio
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "id_usuario", nullable = false)
    private Integer idUsuario;

    @Column(name = "id_emergencia", nullable = false)
    private Integer idEmergencia;

    @Column(name = "fecha_donacion", nullable = false)
    private LocalDateTime fechaDonacion;

    @Enumerated(EnumType.STRING)
    @Column(name = "forma_entrega", nullable = false)
    private FormaEntrega formaEntrega;


    // la fk interna entre donacion y itemdonado D: ::
    @JsonIgnore
    @OneToMany(mappedBy = "donacion", cascade = CascadeType.ALL)
    private List<ItemDonado> items;

}

package com.donaton.donaciones_service.controller;

import com.donaton.donaciones_service.dto.EmergenciaDTO;
import com.donaton.donaciones_service.dto.UsuarioDTO;
import com.donaton.donaciones_service.model.Donacion;
import com.donaton.donaciones_service.service.DonacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;


@RestController
@RequestMapping("/api/v1/donaciones")


@Tag(name = "Donaciones", description = "Operaciones de gestión de donaciones.")
public class DonacionController {

    @Autowired
    private DonacionService donacionService;

    @Operation(summary = "Listar todas las donaciones.")
    @GetMapping
    public ResponseEntity<List<Donacion>> getDonaciones() {
        List<Donacion> lista = donacionService.getDonaciones();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(lista); // 200
        }
    }

    @Operation(summary = "Obtener una donación por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<Donacion> getDonacion(@PathVariable Integer id) {
        Optional<Donacion> donacion = donacionService.getDonacion(id);

        if (donacion.isPresent()) {
            return ResponseEntity.ok(donacion.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<Donacion> getDonacion(@PathVariable Integer id) {

        Donacion donacion = donacionService.getDonacion(id).orElseThrow();
        EntityModel<Donacion> model = EntityModel.of(donacion);

        model.add(
                linkTo(
                        methodOn(DonacionController.class)
                                .getDonacion(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva donación.")
    @PostMapping
    public ResponseEntity<Donacion> saveDonacion(@Valid @RequestBody Donacion donacion) {
        Donacion nuevaDonacion = donacionService.saveDonacion(donacion);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevaDonacion);
    }

    @Operation(summary = "Actualizar una donación existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Donacion> updateDonacion(@PathVariable Integer id, @Valid @RequestBody Donacion donacion) {
        Optional<Donacion> existe = donacionService.getDonacion(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        donacion.setId(id); // Seteamos el ID correspondiente a la Donacion
        Donacion donacionActualizada = donacionService.updateDonacion(donacion);
        return ResponseEntity.ok(donacionActualizada); // 200
    }

    @Operation(summary = "Eliminar una donación por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDonacion(@PathVariable Integer id) {
        try {
            donacionService.deleteDonacion(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }


    @Operation(summary = "Listar usuarios externos.")
    @GetMapping("/usuario")
    public ResponseEntity<List<UsuarioDTO>> listarUsuarios() {
        List<UsuarioDTO> usuarios = donacionService.obtenerUsuariosExternos();
        if (usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(usuarios);
        }
    }


    @Operation(summary = "Listar emergencias externas.")
    @GetMapping("/emergencia")
    public ResponseEntity<List<EmergenciaDTO>> listarEmergencias() {
        List<EmergenciaDTO> emergencias = donacionService.obtenerEmergenciasExternos();

        if (emergencias.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(emergencias);
        }
    }



}
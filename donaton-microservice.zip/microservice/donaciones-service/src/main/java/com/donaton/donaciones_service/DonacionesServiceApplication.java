package com.donaton.donaciones_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class DonacionesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DonacionesServiceApplication.class, args);
	}

}

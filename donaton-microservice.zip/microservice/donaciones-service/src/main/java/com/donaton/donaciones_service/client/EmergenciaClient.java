package com.donaton.donaciones_service.client;

import com.donaton.donaciones_service.dto.EmergenciaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class EmergenciaClient {

    @Autowired
    @Qualifier("emergenciasWebClient") // <-- COINCIDE CON EL PUERTO 8082
    private WebClient webClient;

    public List<EmergenciaDTO> obtenerEmergencias() {
        return webClient
                .get()
                .uri("/api/v1/emergencia") // La ruta del puerto 8082
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<List<EmergenciaDTO>>() {})
                .block();
    }
}
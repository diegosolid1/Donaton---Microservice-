package com.donaton.donaciones_service.dto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
//@JsonIgnoreProperties(ignoreUnknown = true)
public class UsuarioDTO {
    private Integer idUsuario;
    private String nombre;
    private String correo;
    private RolDTO rol;}
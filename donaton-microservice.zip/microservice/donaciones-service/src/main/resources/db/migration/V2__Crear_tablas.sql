-- v2: Creación de tablas para la base de datos donaton_donaciones

-- 1. Crear la tabla principal: donacion
CREATE TABLE `donacion` (
                            `id` INT(11) NOT NULL AUTO_INCREMENT,
                            `id_usuario` INT(11) NOT NULL,
                            `id_emergencia` INT(11) NOT NULL,
                            `fecha_donacion` DATETIME NOT NULL,
                            `forma_entrega` ENUM('Monetaria', 'Insumos_Presencial', 'Insumos_Envio') NOT NULL,
                            PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- 2. Crear la tabla dependiente: itemdonado
CREATE TABLE `itemdonado` (
                              `id` INT(11) NOT NULL AUTO_INCREMENT,
                              `descripcion_producto` VARCHAR(100) NOT NULL,
                              `cantidad` INT(11) NOT NULL,
                              `donacion_id` INT(11) DEFAULT NULL,
                              `unidad_medida` ENUM('Unidades', 'Kilogramos', 'Litros') NOT NULL,
                              PRIMARY KEY (`id`),
                              KEY `fk_donacion_itemDonado` (`donacion_id`),
                              CONSTRAINT `fk_donacion_itemDonado` FOREIGN KEY (`donacion_id`) REFERENCES `donacion` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
-- v3: Inserción de datos iniciales

-- Insertar Donaciones
-- (Suponiendo IDs secuenciales generados de manera automática: 1, 2 y 3)
INSERT INTO `donacion` (`id_usuario`, `id_emergencia`, `fecha_donacion`, `forma_entrega`) VALUES
                                                                                              (501, 10, '2026-05-24 10:15:00', 'Insumos_Presencial'),
                                                                                              (502, 10, '2026-05-24 11:30:00', 'Monetaria'),
                                                                                              (503, 11, '2026-05-24 14:45:00', 'Insumos_Envio');

-- Insertar Ítems Donados
-- (Asociados a las donaciones creadas anteriormente)
INSERT INTO `itemdonado` (`descripcion_producto`, `cantidad`, `donacion_id`, `unidad_medida`) VALUES
-- Ítems pertenecientes a la donación presencial (ID: 1)
('Agua Mineral embotellada', 50, 1, 'Litros'),
('Arroz en bolsa', 25, 1, 'Kilogramos'),
('Cobijas de lana', 10, 1, 'Unidades'),

-- La donación con ID: 2 fue 'Monetaria', por lo tanto no lleva ítems en esta tabla.

-- Ítems pertenecientes a la donación por envío (ID: 3)
('Aceite de cocina', 12, 3, 'Litros'),
('Enlatados de atún', 40, 3, 'Unidades');
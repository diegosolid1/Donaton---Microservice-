package com.donaton.donaciones_service;

import com.donaton.donaciones_service.model.Donacion;
import com.donaton.donaciones_service.model.ItemDonado;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionDonacionesTest {

    // ==========================================
    // TESTS DE DONACIÓN
    // ==========================================

    @Test
    void registrarDonacion() {
        Donacion donacion = new Donacion();
        Faker faker = new Faker();

        donacion.setId(faker.number().positive());
        donacion.setIdUsuario(faker.number().positive());
        donacion.setIdEmergencia(faker.number().positive());
        donacion.setFechaDonacion(LocalDateTime.now());

        // Obtener una forma de entrega aleatoria del Enum
        Donacion.FormaEntrega[] formas = Donacion.FormaEntrega.values();
        Donacion.FormaEntrega formaAleatoria = formas[faker.random().nextInt(formas.length)];
        donacion.setFormaEntrega(formaAleatoria);

        System.out.println("ID Donación: " + donacion.getId());
        System.out.println("ID Usuario: " + donacion.getIdUsuario());
        System.out.println("ID Emergencia: " + donacion.getIdEmergencia());
        System.out.println("Fecha Donación: " + donacion.getFechaDonacion());
        System.out.println("Forma de Entrega: " + donacion.getFormaEntrega());

        assertNotNull(donacion);
        assertNotNull(donacion.getFormaEntrega());
        assertNotNull(donacion.getFechaDonacion());
    }

    @Test
    void probarIdsYFechaDonacion() {
        Donacion donacion = new Donacion();

        Integer idUsuarioEsperado = 15;
        Integer idEmergenciaEsperada = 3;
        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 5, 10, 14, 30);

        donacion.setIdUsuario(idUsuarioEsperado);
        donacion.setIdEmergencia(idEmergenciaEsperada);
        donacion.setFechaDonacion(fechaEsperada);

        System.out.println("ID Usuario asignado: " + donacion.getIdUsuario());
        System.out.println("Fecha asignada: " + donacion.getFechaDonacion());

        assertEquals(idUsuarioEsperado, donacion.getIdUsuario());
        assertEquals(idEmergenciaEsperada, donacion.getIdEmergencia());
        assertEquals(fechaEsperada, donacion.getFechaDonacion());
    }

    @Test
    void probarFormaEntrega() {
        Donacion donacion = new Donacion();

        Donacion.FormaEntrega formaEsperada = Donacion.FormaEntrega.Monetaria;
        donacion.setFormaEntrega(formaEsperada);

        System.out.println("Forma de entrega asignada: " + donacion.getFormaEntrega());

        assertEquals(formaEsperada, donacion.getFormaEntrega());
    }

    // ==========================================
    // TESTS DE ITEM DONADO
    // ==========================================

    @Test
    void registrarItemDonado() {
        ItemDonado item = new ItemDonado();
        Faker faker = new Faker();

        item.setId(faker.number().positive());
        item.setDescripcionProducto(faker.commerce().productName());
        item.setCantidad(faker.number().numberBetween(1, 100));

        // Obtener una unidad de medida aleatoria del Enum
        ItemDonado.UnidadMedida[] unidades = ItemDonado.UnidadMedida.values();
        ItemDonado.UnidadMedida unidadAleatoria = unidades[faker.random().nextInt(unidades.length)];
        item.setUnidadMedida(unidadAleatoria);

        System.out.println("ID Item: " + item.getId());
        System.out.println("Descripción: " + item.getDescripcionProducto());
        System.out.println("Cantidad: " + item.getCantidad());
        System.out.println("Unidad de Medida: " + item.getUnidadMedida());

        assertNotNull(item);
        assertNotNull(item.getDescripcionProducto());
    }

    @Test
    void probarDescripcionYCantidad() {
        ItemDonado item = new ItemDonado();
        Faker faker = new Faker();

        String descripcionEsperada = "Agua Mineral sin gas";
        Integer cantidadEsperada = 50;

        item.setDescripcionProducto(descripcionEsperada);
        item.setCantidad(cantidadEsperada);

        System.out.println("Descripción asignada: " + item.getDescripcionProducto());
        System.out.println("Cantidad asignada: " + item.getCantidad());

        assertEquals(descripcionEsperada, item.getDescripcionProducto());
        assertEquals(cantidadEsperada, item.getCantidad());
    }

    @Test
    void probarUnidadMedida() {
        ItemDonado item = new ItemDonado();

        ItemDonado.UnidadMedida unidadEsperada = ItemDonado.UnidadMedida.Litros;
        item.setUnidadMedida(unidadEsperada);

        System.out.println("Unidad de medida asignada: " + item.getUnidadMedida());

        assertEquals(unidadEsperada, item.getUnidadMedida());
    }
}

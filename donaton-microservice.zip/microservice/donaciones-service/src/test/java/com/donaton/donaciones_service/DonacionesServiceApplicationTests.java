package com.donaton.donaciones_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonacionesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

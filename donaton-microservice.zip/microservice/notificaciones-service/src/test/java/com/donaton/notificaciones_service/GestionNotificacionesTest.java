package com.donaton.notificaciones_service;

import com.donaton.notificaciones_service.model.HistorialEnvio;
import com.donaton.notificaciones_service.model.Notificacion;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionNotificacionesTest {

    // ==========================================
    // TESTS DE NOTIFICACIÓN
    // ==========================================

    @Test
    void registrarNotificacion() {
        Notificacion notificacion = new Notificacion();
        Faker faker = new Faker();

        notificacion.setIdNotificacion(faker.number().positive());
        notificacion.setIdUsuarioDestino(faker.number().positive());
        notificacion.setMensaje(faker.lorem().sentence());

        // Obtener un medio de envío aleatorio del Enum
        Notificacion.MedioEnvio[] medios = Notificacion.MedioEnvio.values();
        Notificacion.MedioEnvio medioAleatorio = medios[faker.random().nextInt(medios.length)];
        notificacion.setMedioEnvio(medioAleatorio);

        // Obtener un estado actual aleatorio del Enum
        Notificacion.EstadoActual[] estados = Notificacion.EstadoActual.values();
        Notificacion.EstadoActual estadoAleatorio = estados[faker.random().nextInt(estados.length)];
        notificacion.setEstadoActual(estadoAleatorio);

        System.out.println("ID Notificación: " + notificacion.getIdNotificacion());
        System.out.println("ID Usuario Destino: " + notificacion.getIdUsuarioDestino());
        System.out.println("Mensaje: " + notificacion.getMensaje());
        System.out.println("Medio de Envío: " + notificacion.getMedioEnvio());
        System.out.println("Estado Actual: " + notificacion.getEstadoActual());

        assertNotNull(notificacion);
        assertNotNull(notificacion.getMensaje());
        assertNotNull(notificacion.getMedioEnvio());
        assertNotNull(notificacion.getEstadoActual());
    }

    @Test
    void probarMensajeYDestinoNotificacion() {
        Notificacion notificacion = new Notificacion();

        Integer idDestinoEsperado = 42;
        String mensajeEsperado = "Su donación ha sido recibida con éxito. ¡Gracias!";

        notificacion.setIdUsuarioDestino(idDestinoEsperado);
        notificacion.setMensaje(mensajeEsperado);

        System.out.println("ID Destino asignado: " + notificacion.getIdUsuarioDestino());
        System.out.println("Mensaje asignado: " + notificacion.getMensaje());

        assertEquals(idDestinoEsperado, notificacion.getIdUsuarioDestino());
        assertEquals(mensajeEsperado, notificacion.getMensaje());
    }

    @Test
    void probarEnumsNotificacion() {
        Notificacion notificacion = new Notificacion();

        Notificacion.MedioEnvio medioEsperado = Notificacion.MedioEnvio.Email;
        Notificacion.EstadoActual estadoEsperado = Notificacion.EstadoActual.Enviado;

        notificacion.setMedioEnvio(medioEsperado);
        notificacion.setEstadoActual(estadoEsperado);

        System.out.println("Medio asignado: " + notificacion.getMedioEnvio());
        System.out.println("Estado asignado: " + notificacion.getEstadoActual());

        assertEquals(medioEsperado, notificacion.getMedioEnvio());
        assertEquals(estadoEsperado, notificacion.getEstadoActual());
    }

    // ==========================================
    // TESTS DE HISTORIAL DE ENVÍO
    // ==========================================

    @Test
    void registrarHistorialEnvio() {
        HistorialEnvio historial = new HistorialEnvio();
        Faker faker = new Faker();

        historial.setIdHistorial(faker.number().positive());
        historial.setFechaIntento(LocalDateTime.now());

        // Obtener un estado de envío aleatorio del Enum
        HistorialEnvio.EstadoEnvio[] estadosEnvio = HistorialEnvio.EstadoEnvio.values();
        HistorialEnvio.EstadoEnvio estadoAleatorio = estadosEnvio[faker.random().nextInt(estadosEnvio.length)];
        historial.setEstadoEnvio(estadoAleatorio);

        System.out.println("ID Historial: " + historial.getIdHistorial());
        System.out.println("Fecha Intento: " + historial.getFechaIntento());
        System.out.println("Estado Envío: " + historial.getEstadoEnvio());

        assertNotNull(historial);
        assertNotNull(historial.getFechaIntento());
        assertNotNull(historial.getEstadoEnvio());
    }

    @Test
    void probarFechaIntentoHistorial() {
        HistorialEnvio historial = new HistorialEnvio();

        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 9, 1, 10, 0);
        historial.setFechaIntento(fechaEsperada);

        System.out.println("Fecha de intento asignada: " + historial.getFechaIntento());

        assertEquals(fechaEsperada, historial.getFechaIntento());
    }

    @Test
    void probarEstadoEnvioHistorial() {
        HistorialEnvio historial = new HistorialEnvio();

        HistorialEnvio.EstadoEnvio estadoEsperado = HistorialEnvio.EstadoEnvio.Fallido;
        historial.setEstadoEnvio(estadoEsperado);

        System.out.println("Estado de envío asignado: " + historial.getEstadoEnvio());

        assertEquals(estadoEsperado, historial.getEstadoEnvio());
    }
}
package com.donaton.notificaciones_service.dto;

import lombok.Data;

@Data
public class RolDTO {
    private Integer id;
    private String nombreRol;
}

package com.donaton.notificaciones_service.dto;
import lombok.Data;

@Data
public class UsuarioDTO {
    private Integer idUsuario;
    private String nombre;
    private String correo;
    private RolDTO rol;}
package com.donaton.notificaciones_service.controller;

import com.donaton.notificaciones_service.dto.UsuarioDTO;
import com.donaton.notificaciones_service.model.Notificacion;
import com.donaton.notificaciones_service.service.NotificacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/notificacion")
@Tag(name = "Notificaciones", description = "Operaciones de gestión y emisión de notificaciones.")
public class NotificacionController {

    @Autowired
    private NotificacionService notificacionService;

    @Operation(summary = "Listar todas las notificaciones.")
    @GetMapping
    public ResponseEntity<List<Notificacion>> listarNotificaciones() {
        List<Notificacion> notificaciones = notificacionService.getNotificaciones();

        if (notificaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(notificaciones);
        }
    }

    @Operation(summary = "Obtener una notificación por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<Notificacion> buscarPorId(@PathVariable Integer id) { // Cambiado a Integer
        Optional<Notificacion> notificacion = notificacionService.getNotificacion(id);

        if (notificacion.isPresent()) {
            return ResponseEntity.ok(notificacion.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    } */

    public EntityModel<Notificacion> getNotificacion(@PathVariable Integer id) {

        Notificacion notificacion = notificacionService.getNotificacion(id).orElseThrow();
        EntityModel<Notificacion> model = EntityModel.of(notificacion);

        model.add(
                linkTo(
                        methodOn(NotificacionController.class)
                                .getNotificacion(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva notificación.")
    @PostMapping
    public ResponseEntity<Notificacion> agregarNotificacion(@Valid @RequestBody Notificacion notificacion) {
        try {
            Notificacion nuevaNotificacion = notificacionService.saveNotificacion(notificacion);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevaNotificacion);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar una notificación existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Notificacion> editarNotificacion(@Valid @RequestBody Notificacion notificacion, @PathVariable Integer id) { // Cambiado a Integer
        Optional<Notificacion> existe = notificacionService.getNotificacion(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        notificacion.setIdNotificacion(id);
        try {
            Notificacion actualizado = notificacionService.saveNotificacion(notificacion);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar una notificación por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarNotificacion(@PathVariable Integer id) { // Cambiado a Integer
        try {
            notificacionService.deleteNotificacion(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Listar usuarios externos asociados.")
    @GetMapping("/usuario")
    public ResponseEntity<List<UsuarioDTO>> listarUsuarios() {
        List<UsuarioDTO> usuarios = notificacionService.obtenerUsuariosExternos();

        if (usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(usuarios);
        }
    }
}
package com.donaton.notificaciones_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "notificacion")
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_notificacion")
    private Integer idNotificacion;

    @NotNull(message = "El ID de usuario destino es obligatorio")
    @Column(name = "id_usuario_destino") // Eliminado el length = 36
    private Integer idUsuarioDestino; // Cambiado de String a Integer para coincidir con la DB

    @NotNull(message = "El mensaje es obligatorio")
    @Column(name = "mensaje", columnDefinition = "TEXT")
    private String mensaje;

    @NotNull(message = "El medio de envío es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "medio_envio", columnDefinition = "ENUM('Email', 'SMS', 'Push_App')")
    private MedioEnvio medioEnvio;

    @NotNull(message = "El estado actual es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "estado_actual", columnDefinition = "ENUM('Pendiente', 'Enviado', 'Fallido')")
    private EstadoActual estadoActual;

    public enum MedioEnvio {
        Email,
        SMS,
        Push_App;
    }

    public enum EstadoActual {
        Pendiente,
        Enviado,
        Fallido;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "notificacion", cascade = CascadeType.ALL)
    private List<HistorialEnvio> historiales;
}
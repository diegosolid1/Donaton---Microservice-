package com.donaton.notificaciones_service.repository;

import com.donaton.notificaciones_service.model.HistorialEnvio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface HistorialEnvioRepository extends JpaRepository<HistorialEnvio, Integer> {

}
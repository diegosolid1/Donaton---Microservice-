package com.donaton.notificaciones_service.service;

import com.donaton.notificaciones_service.model.HistorialEnvio;
import com.donaton.notificaciones_service.repository.HistorialEnvioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HistorialEnvioService {

    @Autowired
    private HistorialEnvioRepository historialEnvioRepository;

    public List<HistorialEnvio> getHistorialesEnvio() {
        return historialEnvioRepository.findAll();
    }

    public Optional<HistorialEnvio> getHistorialEnvio(Integer id) { // Cambiado a Integer
        return historialEnvioRepository.findById(id);
    }

    public HistorialEnvio saveHistorialEnvio(HistorialEnvio historialEnvio) {
        return historialEnvioRepository.save(historialEnvio);
    }

    public HistorialEnvio updateHistorialEnvio(Integer id, HistorialEnvio historialEnvio) { // Cambiado a Integer
        Optional<HistorialEnvio> existe = getHistorialEnvio(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Historial de envío no encontrado con el ID: " + id);
        } else {
            historialEnvio.setIdHistorial(id);
            return historialEnvioRepository.save(historialEnvio);
        }
    }

    public void deleteHistorialEnvio(Integer id) { // Cambiado a Integer
        if (historialEnvioRepository.existsById(id)) {
            historialEnvioRepository.deleteById(id);
        } else {
            throw new RuntimeException("Historial de envío no encontrado con el ID: " + id);
        }
    }
}
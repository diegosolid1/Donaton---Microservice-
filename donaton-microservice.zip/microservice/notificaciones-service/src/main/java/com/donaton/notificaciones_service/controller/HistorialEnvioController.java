package com.donaton.notificaciones_service.controller;

import com.donaton.notificaciones_service.model.HistorialEnvio;
import com.donaton.notificaciones_service.service.HistorialEnvioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/historial-envio")
@Tag(name = "Historial de Envíos", description = "Operaciones de consulta y registro del histórico de notificaciones enviadas.")
public class HistorialEnvioController {

    @Autowired
    private HistorialEnvioService historialEnvioService;

    @Operation(summary = "Listar todo el historial de envíos.")
    @GetMapping
    public ResponseEntity<List<HistorialEnvio>> listarHistorialesEnvio() {
        List<HistorialEnvio> historiales = historialEnvioService.getHistorialesEnvio();

        if (historiales.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(historiales);
        }
    }

    @Operation(summary = "Obtener un registro de historial por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<HistorialEnvio> buscarPorId(@PathVariable Integer id) {
        Optional<HistorialEnvio> historial = historialEnvioService.getHistorialEnvio(id);

        if (historial.isPresent()) {
            return ResponseEntity.ok(historial.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }  */
    public EntityModel<HistorialEnvio> getHistorialEnvio(@PathVariable Integer id) {

        HistorialEnvio historialEnvio = historialEnvioService.getHistorialEnvio(id).orElseThrow();
        EntityModel<HistorialEnvio> model = EntityModel.of(historialEnvio);

        model.add(
                linkTo(
                        methodOn(HistorialEnvioController.class)
                                .getHistorialEnvio(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar un nuevo elemento en el historial.")
    @PostMapping
    public ResponseEntity<HistorialEnvio> agregarHistorialEnvio(@Valid @RequestBody HistorialEnvio historialEnvio) {
        try {
            HistorialEnvio nuevoHistorial = historialEnvioService.saveHistorialEnvio(historialEnvio);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoHistorial);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar un registro de historial existente.")
    @PutMapping("/{id}")
    public ResponseEntity<HistorialEnvio> editarHistorialEnvio(@Valid @RequestBody HistorialEnvio historialEnvio, @PathVariable Integer id) { // Cambiado a Integer
        Optional<HistorialEnvio> existe = historialEnvioService.getHistorialEnvio(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        historialEnvio.setIdHistorial(id);
        try {
            HistorialEnvio actualizado = historialEnvioService.saveHistorialEnvio(historialEnvio);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar un registro de historial por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarHistorialEnvio(@PathVariable Integer id) { // Cambiado a Integer
        try {
            historialEnvioService.deleteHistorialEnvio(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


}
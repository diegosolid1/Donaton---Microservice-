package com.donaton.notificaciones_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "historialenvio")
public class HistorialEnvio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_historial")
    private Integer idHistorial;

    @NotNull(message = "La notificación asociada es obligatoria")
    @ManyToOne
    @JoinColumn(name = "id_notificacion", referencedColumnName = "id_notificacion")
    private Notificacion notificacion;

    @NotNull(message = "La fecha de intento es obligatoria")
    @Column(name = "fecha_intento")
    private LocalDateTime fechaIntento;

    @NotNull(message = "El estado de envío es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "estado_envio")
    private EstadoEnvio estadoEnvio;

    public enum EstadoEnvio {
        Pendiente,
        Enviado,
        Fallido;
    }
}
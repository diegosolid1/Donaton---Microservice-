package com.donaton.notificaciones_service.service;

import com.donaton.notificaciones_service.client.AutenticacionClient;
import com.donaton.notificaciones_service.dto.UsuarioDTO;
import com.donaton.notificaciones_service.model.Notificacion;
import com.donaton.notificaciones_service.repository.NotificacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository notificacionRepository;
    @Autowired
    private AutenticacionClient autenticacionClient;

    public List<Notificacion> getNotificaciones() {
        return notificacionRepository.findAll();
    }

    public Optional<Notificacion> getNotificacion(Integer id) { // Cambiado a Integer
        return notificacionRepository.findById(id);
    }

    public Notificacion saveNotificacion(Notificacion notificacion) {
        return notificacionRepository.save(notificacion);
    }

    public Notificacion updateNotificacion(Integer id, Notificacion notificacion) { // Cambiado a Integer
        Optional<Notificacion> existe = getNotificacion(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Notificación no encontrada con el ID: " + id);
        } else {
            notificacion.setIdNotificacion(id);
            return notificacionRepository.save(notificacion);
        }
    }

    public void deleteNotificacion(Integer id) { // Cambiado a Integer
        if (notificacionRepository.existsById(id)) {
            notificacionRepository.deleteById(id);
        } else {
            throw new RuntimeException("Notificación no encontrada con el ID: " + id);
        }
    }

    public List<UsuarioDTO> obtenerUsuariosExternos() {
        return autenticacionClient.obtenerUsuarios();
    }
}
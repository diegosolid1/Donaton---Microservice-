DROP TABLE IF EXISTS `historialenvio`;
DROP TABLE IF EXISTS `notificacion`;

-- Estructura de tabla para `notificacion`
CREATE TABLE `notificacion` (
                                `id_notificacion` INT NOT NULL AUTO_INCREMENT,
                                `id_usuario_destino` INT NOT NULL,
                                `mensaje` TEXT NOT NULL,
                                `medio_envio` ENUM('Email', 'SMS', 'Push_App') NOT NULL,
                                `estado_actual` ENUM('Pendiente', 'Enviado', 'Fallido') NOT NULL,
                                PRIMARY KEY (`id_notificacion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Estructura de tabla para `historialenvio`
CREATE TABLE `historialenvio` (
                                  `id_historial` INT NOT NULL AUTO_INCREMENT,
                                  `id_notificacion` INT NOT NULL,
                                  `fecha_intento` DATETIME NOT NULL,
                                  `estado_envio` ENUM('Pendiente', 'Enviado', 'Fallido') NOT NULL,
                                  PRIMARY KEY (`id_historial`),
                                  KEY `fk_notificacion_historial` (`id_notificacion`),
                                  CONSTRAINT `fk_notificacion_historial` FOREIGN KEY (`id_notificacion`) REFERENCES `notificacion` (`id_notificacion`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
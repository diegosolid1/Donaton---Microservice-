-- Volcado de datos para la tabla `notificacion`
INSERT INTO `notificacion` (`id_notificacion`, `id_usuario_destino`, `mensaje`, `medio_envio`, `estado_actual`) VALUES
                                                                                                                    (1, 101, 'Su cuenta de voluntario ha sido aprobada con éxito.', 'Email', 'Fallido'),
                                                                                                                    (2, 102, 'Su turno de voluntariado en Salud ha sido confirmado.', 'Email', 'Enviado'),
                                                                                                                    (3, 103, 'Alerta de rescate: Se necesita apoyo urgente en Zona Norte.', 'SMS', 'Enviado'),
                                                                                                                    (4, 104, 'Nuevo despacho asignado para la ruta de logística.', 'Push_App', 'Pendiente'),
                                                                                                                    (5, 105, 'Reunión de apoyo emocional programada para las 15:00.', 'Email', 'Enviado'),
                                                                                                                    (6, 106, 'Gracias por registrarte como voluntario general.', 'Email', 'Enviado'),
                                                                                                                    (7, 107, 'Su código de verificación es: 4589.', 'SMS', 'Fallido'),
                                                                                                                    (8, 108, 'Cambio de horario en su asignación de la tarde.', 'Push_App', 'Enviado'),
                                                                                                                    (9, 109, 'Stock de acopio crítico. Se requiere apoyo en empaque.', 'Push_App', 'Pendiente'),
                                                                                                                    (10, 110, 'Recordatorio: Su turno inicia en 1 hora.', 'SMS', 'Enviado');

-- Volcado de datos para la tabla `historialenvio`
INSERT INTO `historialenvio` (`id_historial`, `id_notificacion`, `fecha_intento`, `estado_envio`) VALUES
                                                                                                      (1, 1, '2026-05-25 10:45:10', 'Fallido'),
                                                                                                      (2, 2, '2026-05-25 08:30:00', 'Enviado'),
                                                                                                      (3, 3, '2026-05-25 08:45:12', 'Enviado'),
                                                                                                      (4, 4, '2026-05-25 09:00:00', 'Pendiente'),
                                                                                                      (5, 5, '2026-05-25 09:15:30', 'Enviado'),
                                                                                                      (6, 6, '2026-05-25 09:30:22', 'Enviado'),
                                                                                                      (7, 7, '2026-05-25 09:45:00', 'Fallido'),
                                                                                                      (8, 8, '2026-05-25 10:00:15', 'Enviado'),
                                                                                                      (9, 9, '2026-05-25 10:15:00', 'Pendiente'),
                                                                                                      (10, 10, '2026-05-25 10:30:45', 'Enviado');
package com.donaton.necesidades;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NecesidadesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

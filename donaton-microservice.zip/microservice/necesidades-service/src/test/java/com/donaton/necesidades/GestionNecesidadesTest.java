package com.donaton.necesidades;

import com.donaton.necesidades.model.DetalleNecesidad;
import com.donaton.necesidades.model.Necesidad;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionNecesidadesTest {

    // ==========================================
    // TESTS DE NECESIDAD
    // ==========================================

    @Test
    void registrarNecesidad() {
        Necesidad necesidad = new Necesidad();
        Faker faker = new Faker();

        necesidad.setId(faker.number().positive());
        necesidad.setFechaCreacion(LocalDateTime.now());

        // Obtener un estado aleatorio del Enum EstadoNecesidad
        Necesidad.EstadoNecesidad[] estados = Necesidad.EstadoNecesidad.values();
        Necesidad.EstadoNecesidad estadoAleatorio = estados[faker.random().nextInt(estados.length)];
        necesidad.setEstado(estadoAleatorio);

        System.out.println("ID Necesidad: " + necesidad.getId());
        System.out.println("Fecha de Creación: " + necesidad.getFechaCreacion());
        System.out.println("Estado Necesidad: " + necesidad.getEstado());

        assertNotNull(necesidad);
        assertNotNull(necesidad.getFechaCreacion());
        assertNotNull(necesidad.getEstado());
    }

    @Test
    void probarFechaCreacionNecesidad() {
        Necesidad necesidad = new Necesidad();

        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 8, 5, 9, 15);
        necesidad.setFechaCreacion(fechaEsperada);

        System.out.println("Fecha de creación asignada: " + necesidad.getFechaCreacion());

        assertEquals(fechaEsperada, necesidad.getFechaCreacion());
    }

    @Test
    void probarEstadoNecesidad() {
        Necesidad necesidad = new Necesidad();

        Necesidad.EstadoNecesidad estadoEsperado = Necesidad.EstadoNecesidad.EnProceso;
        necesidad.setEstado(estadoEsperado);

        System.out.println("Estado asignado: " + necesidad.getEstado());

        assertEquals(estadoEsperado, necesidad.getEstado());
    }

    // ==========================================
    // TESTS DE DETALLE DE NECESIDAD
    // ==========================================

    @Test
    void registrarDetalleNecesidad() {
        DetalleNecesidad detalle = new DetalleNecesidad();
        Faker faker = new Faker();

        detalle.setId(faker.number().positive());
        detalle.setCantidadSolicitada(faker.number().numberBetween(50, 500));

        // Simulamos que la cantidad recibida es un número entre 0 y la cantidad solicitada
        detalle.setCantidadRecibida(faker.number().numberBetween(0, detalle.getCantidadSolicitada()));

        // Obtener una categoría aleatoria del Enum CategoriaInsumo
        DetalleNecesidad.CategoriaInsumo[] categorias = DetalleNecesidad.CategoriaInsumo.values();
        DetalleNecesidad.CategoriaInsumo categoriaAleatoria = categorias[faker.random().nextInt(categorias.length)];
        detalle.setCategoriaInsumo(categoriaAleatoria);

        System.out.println("ID Detalle: " + detalle.getId());
        System.out.println("Categoría Insumo: " + detalle.getCategoriaInsumo());
        System.out.println("Cantidad Solicitada: " + detalle.getCantidadSolicitada());
        System.out.println("Cantidad Recibida: " + detalle.getCantidadRecibida());

        assertNotNull(detalle);
        assertNotNull(detalle.getCategoriaInsumo());
    }

    @Test
    void probarCantidadesDetalle() {
        DetalleNecesidad detalle = new DetalleNecesidad();

        Integer solicitadaEsperada = 100;
        Integer recibidaEsperada = 45;

        detalle.setCantidadSolicitada(solicitadaEsperada);
        detalle.setCantidadRecibida(recibidaEsperada);

        System.out.println("Cantidad solicitada asignada: " + detalle.getCantidadSolicitada());
        System.out.println("Cantidad recibida asignada: " + detalle.getCantidadRecibida());

        assertEquals(solicitadaEsperada, detalle.getCantidadSolicitada());
        assertEquals(recibidaEsperada, detalle.getCantidadRecibida());
    }

    @Test
    void probarCategoriaInsumo() {
        DetalleNecesidad detalle = new DetalleNecesidad();

        DetalleNecesidad.CategoriaInsumo categoriaEsperada = DetalleNecesidad.CategoriaInsumo.Alimentos;
        detalle.setCategoriaInsumo(categoriaEsperada);

        System.out.println("Categoría asignada: " + detalle.getCategoriaInsumo());

        assertEquals(categoriaEsperada, detalle.getCategoriaInsumo());
    }
}
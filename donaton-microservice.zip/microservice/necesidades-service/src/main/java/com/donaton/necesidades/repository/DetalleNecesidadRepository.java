package com.donaton.necesidades.repository;

import com.donaton.necesidades.model.DetalleNecesidad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetalleNecesidadRepository extends JpaRepository<DetalleNecesidad, Integer> {
}

package com.donaton.necesidades.service;

import com.donaton.necesidades.model.Necesidad;
import com.donaton.necesidades.repository.NecesidadRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
public class NecesidadService {

    @Autowired
    private NecesidadRepository necesidadRepository;

    public List<Necesidad> listarTodos() {
        return necesidadRepository.findAll();
    }

    public Optional<Necesidad> buscarPorId(Integer id) {
        return necesidadRepository.findById(id);
    }

    public Necesidad guardar(Necesidad necesidad) {
        return necesidadRepository.save(necesidad);
    }

    public void eliminar(Integer id) {
        // 1. Verificamos si existe en la base de datos
        if (!necesidadRepository.existsById(id)) {
            // Si no existe, lanzamos este error con el mensaje que queramos
            throw new EntityNotFoundException("No se pudo eliminar: La necesidad con ID " + id + " no existe.");
        }

        // 2. Si existe, lo borramos con tranquilidad
        necesidadRepository.deleteById(id);
    }

    public Necesidad actualizar(Integer id, Necesidad necesidad) {
        Optional<Necesidad> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Necesidad no encontrada con el ID: " + id);
        } else {

            necesidad.setId(id);
            return necesidadRepository.save(necesidad);
        }
    }


}

package com.donaton.necesidades.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Table(name = "detalle_necesidad")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class DetalleNecesidad {

    public enum CategoriaInsumo {
        Alimentos,
        Agua,
        Medicamentos,
        Ropa,
        Herramientas
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotNull(message = "la categoria del insumo es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "categoria_insumo")
    private CategoriaInsumo categoriaInsumo;

    @NotNull(message = "la cantidad solicitada es obligatorio")
    @Column(name = "cantidad_solicitada")
    private Integer cantidadSolicitada;

    @NotNull(message = "la cantidad recibida es obligatorio")
    @Column(name = "cantidad_recibida")
    private Integer cantidadRecibida;

    @ManyToOne
    @JoinColumn(name = "id_necesidad")
    private Necesidad necesidad;

}

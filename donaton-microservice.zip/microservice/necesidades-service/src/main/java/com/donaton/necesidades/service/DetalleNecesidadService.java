package com.donaton.necesidades.service;

import com.donaton.necesidades.model.DetalleNecesidad;
import com.donaton.necesidades.repository.DetalleNecesidadRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DetalleNecesidadService {

    @Autowired
    private DetalleNecesidadRepository detalleNecesidadRepository;

    public List<DetalleNecesidad> listarTodos() {
        return detalleNecesidadRepository.findAll();
    }

    public Optional<DetalleNecesidad> buscarPorId(Integer id) {
        return detalleNecesidadRepository.findById(id);
    }

    public DetalleNecesidad guardar(DetalleNecesidad detalleNecesidad) {
        return detalleNecesidadRepository.save(detalleNecesidad);
    }

    public void eliminar(Integer id) {
        // 1. Verificamos si existe en la base de datos
        if (!detalleNecesidadRepository.existsById(id)) {
            // Si no existe, lanzamos este error con el mensaje que queramos
            throw new EntityNotFoundException("No se pudo eliminar: Los detalles de necesidad con ID " + id + " no existe.");
        }

        // 2. Si existe, lo borramos con tranquilidad
        detalleNecesidadRepository.deleteById(id);
    }

    public DetalleNecesidad actualizar(Integer id, DetalleNecesidad detalleNecesidad) {
        Optional<DetalleNecesidad> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Detalle necesidad no encontrada con el ID: " + id);
        } else {

            detalleNecesidad.setId(id);
            return detalleNecesidadRepository.save(detalleNecesidad);
        }
    }


}

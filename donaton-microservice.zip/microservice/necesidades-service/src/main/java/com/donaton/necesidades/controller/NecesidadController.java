package com.donaton.necesidades.controller;

import com.donaton.necesidades.model.Necesidad;
import com.donaton.necesidades.service.NecesidadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/necesidad")
@Tag(name = "Necesidades", description = "Operaciones de gestión de necesidades registradas.")
public class NecesidadController {

    @Autowired
    private NecesidadService necesidadService;

    @Operation(summary = "Listar todas las necesidades.")
    @GetMapping
    public ResponseEntity<List<Necesidad>> listarZonasAfectadas() {
        List<Necesidad> necesidades = necesidadService.listarTodos();

        if (necesidades.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(necesidades); // 200
        }
    }

    @Operation(summary = "Obtener una necesidad por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<Necesidad> ObtenerPorID(@PathVariable Integer id) {
        Optional<Necesidad> necesidad = necesidadService.buscarPorId(id);

        if (necesidad.isPresent()) {
            return ResponseEntity.ok(necesidad.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */

    public EntityModel<Necesidad> getNecesidad(@PathVariable Integer id) {

        Necesidad necesidad = necesidadService.buscarPorId(id).orElseThrow();
        EntityModel<Necesidad> model = EntityModel.of(necesidad);

        model.add(
                linkTo(
                        methodOn(NecesidadController.class)
                                .getNecesidad(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva necesidad.")
    @PostMapping
    public ResponseEntity<Necesidad> crear(@Valid @RequestBody Necesidad necesidad) {
        Necesidad nuevaNecesidad = necesidadService.guardar(necesidad);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevaNecesidad);
    }

    @Operation(summary = "Actualizar una necesidad existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Necesidad> editarZonaAfectada(@Valid @RequestBody Necesidad necesidad, @PathVariable Integer id) {
        Optional<Necesidad> existe = necesidadService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        necesidad.setId(id);
        Necesidad actualizado = necesidadService.actualizar(id, necesidad);
        return ResponseEntity.ok(actualizado); // 200
    }

    @Operation(summary = "Eliminar una necesidad por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        Optional<Necesidad> existe = necesidadService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            necesidadService.eliminar(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
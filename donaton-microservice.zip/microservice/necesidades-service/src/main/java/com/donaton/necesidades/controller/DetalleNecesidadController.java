package com.donaton.necesidades.controller;

import com.donaton.necesidades.model.DetalleNecesidad;
import com.donaton.necesidades.service.DetalleNecesidadService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/detalle")
@Tag(name = "Detalles de Necesidades", description = "Operaciones de gestión sobre el desglose de necesidades.")
public class DetalleNecesidadController {

    @Autowired
    private DetalleNecesidadService detalleNecesidadService;

    @Operation(summary = "Listar todos los detalles de necesidades.")
    @GetMapping
    public ResponseEntity<List<DetalleNecesidad>> listarZonasAfectadas() {
        List<DetalleNecesidad> detalles = detalleNecesidadService.listarTodos();

        if (detalles.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(detalles); // 200
        }
    }

    @Operation(summary = "Obtener un detalle de necesidad por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<DetalleNecesidad> ObtenerPorID(@PathVariable Integer id) {
        Optional<DetalleNecesidad> detalleNecesidad = detalleNecesidadService.buscarPorId(id);

        if (detalleNecesidad.isPresent()) {
            return ResponseEntity.ok(detalleNecesidad.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */
    public EntityModel<DetalleNecesidad> getDetalleNecesidad(@PathVariable Integer id) {

        DetalleNecesidad detalleNecesidad = detalleNecesidadService.buscarPorId(id).orElseThrow();
        EntityModel<DetalleNecesidad> model = EntityModel.of(detalleNecesidad);

        model.add(
                linkTo(
                        methodOn(DetalleNecesidadController.class)
                                .getDetalleNecesidad(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar un nuevo detalle de necesidad.")
    @PostMapping
    public ResponseEntity<DetalleNecesidad> crear(@Valid @RequestBody DetalleNecesidad detalleNecesidad) {
        DetalleNecesidad nuevoDetalleNecesidad = detalleNecesidadService.guardar(detalleNecesidad);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevoDetalleNecesidad);
    }

    @Operation(summary = "Actualizar un detalle de necesidad existente.")
    @PutMapping("/{id}")
    public ResponseEntity<DetalleNecesidad> editarDetalleNecesidad(@Valid @RequestBody DetalleNecesidad detalleNecesidad, @PathVariable Integer id) {
        Optional<DetalleNecesidad> existe = detalleNecesidadService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        detalleNecesidad.setId(id); // Seteamos el ID correspondiente a DetalleNecesidad
        DetalleNecesidad actualizado = detalleNecesidadService.actualizar(id, detalleNecesidad);
        return ResponseEntity.ok(actualizado); // 200
    }

    @Operation(summary = "Eliminar un detalle de necesidad por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        Optional<DetalleNecesidad> existe = detalleNecesidadService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            detalleNecesidadService.eliminar(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
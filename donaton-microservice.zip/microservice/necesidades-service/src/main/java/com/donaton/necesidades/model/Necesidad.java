package com.donaton.necesidades.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Table(name = "necesidad")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Necesidad {

    public enum EstadoNecesidad {
        Abierta,
        EnProceso,
        Cubierta
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "fecha_creacion")
    @NotNull(message = "La fecha de creacion es obligatoria")
    private LocalDateTime fechaCreacion;

    @NotNull(message = "El estado de la necesidad es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "estado")
    private EstadoNecesidad estado;


    @JsonIgnore // Corta el bucle para que no explote el JSON
    @OneToMany(mappedBy = "necesidad", cascade = CascadeType.ALL)
    private List<DetalleNecesidad> detalles;
}

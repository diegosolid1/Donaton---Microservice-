
INSERT INTO necesidad (fecha_creacion, estado) VALUES
                                                   ('2026-05-20 08:30:00', 'Abierta'),
                                                   ('2026-05-21 14:15:00', 'EnProceso'),
                                                   ('2026-05-22 10:00:00', 'Cubierta');



INSERT INTO detalle_necesidad (id_necesidad, categoria_insumo, cantidad_solicitada, cantidad_recibida) VALUES

(1, 'Agua', 100, 10),
(1, 'Alimentos', 50, 0),


(2, 'Ropa', 200, 150),
(2, 'Medicamentos', 30, 15),


(3, 'Herramientas', 20, 20),
(3, 'Agua', 50, 50);
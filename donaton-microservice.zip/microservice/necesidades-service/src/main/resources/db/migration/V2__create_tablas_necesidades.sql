
CREATE TABLE necesidad (
                           id INT AUTO_INCREMENT PRIMARY KEY,
                           fecha_creacion DATETIME NOT NULL,
                           estado ENUM('Abierta', 'EnProceso', 'Cubierta') NOT NULL
);

CREATE TABLE detalle_necesidad (
                                   id INT AUTO_INCREMENT PRIMARY KEY,
                                   id_necesidad INT NOT NULL,
                                   categoria_insumo ENUM('Alimentos', 'Agua', 'Medicamentos', 'Ropa', 'Herramientas') NOT NULL,
                                   cantidad_solicitada INT NOT NULL,
                                   cantidad_recibida INT NOT NULL DEFAULT 0,
                                   CONSTRAINT fk_detalle_necesidad FOREIGN KEY (id_necesidad) REFERENCES necesidad(id) ON DELETE CASCADE
);
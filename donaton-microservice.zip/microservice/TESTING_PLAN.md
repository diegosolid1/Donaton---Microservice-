# Plan de Pruebas - Donaton

## Objetivo General

Validar el correcto funcionamiento de las entidades de los distintos microservicios de la plataforma Donaton, verificando la correcta instanciación, asignación de datos aleatorios (mediante DataFaker), recuperación de atributos y manejo de enumeradores (Enums).

## Herramientas

* Java 21
* Spring Boot
* JUnit 5
* DataFaker

---

## 1. Gestión de Autenticación (`GestionAutenticacionTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-AUTH-01** | `Usuario` | `registrarUsuario` | Verificar que un usuario pueda ser instanciado correctamente con datos aleatorios. | El objeto `Usuario` no es nulo. |
| **CP-AUTH-02** | `Usuario` | `probarPass` | Validar la asignación y recuperación del hash de la contraseña. | La contraseña devuelta coincide con la asignada. |
| **CP-AUTH-03** | `Usuario` | `probarNombre` | Comprobar que el nombre del usuario se guarda y recupera con precisión. | El nombre devuelto es igual al ingresado. |
| **CP-AUTH-04** | `Usuario` | `probarCorreo` | Comprobar que el correo electrónico se asigna y lee correctamente. | El correo devuelto coincide con el ingresado. |
| **CP-AUTH-05** | `Rol` | `registrarRol` | Verificar la instanciación de un rol y la asignación aleatoria de su nombre. | El objeto `Rol` y su `nombreRol` no son nulos. |
| **CP-AUTH-06** | `Rol` | `probarNombreRol` | Validar la asignación explícita de un enumerador `RolNombre`. | El enumerador devuelto coincide con el asignado. |
| **CP-AUTH-07** | `Rol` | `probarIdRol` | Validar la asignación de un ID numérico positivo al rol. | El ID devuelto es igual al asignado. |

---

## 2. Gestión de Centros de Acopio (`GestionCentrosAcopioTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-ACOP-01** | `CentroAcopio` | `registrarCentroAcopio` | Instanciar un centro con datos base y un estado aleatorio. | El objeto y su estado no son nulos. |
| **CP-ACOP-02** | `CentroAcopio` | `probarNombreYDireccionCentro` | Verificar la asignación de campos de texto (nombre y dirección). | Los textos devueltos son exactos a los asignados. |
| **CP-ACOP-03** | `CentroAcopio` | `probarEstadoCentro` | Validar la asignación explícita del enumerador `EstadoCentro`. | El estado devuelto coincide con el asignado. |
| **CP-ACOP-04** | `HorarioAcopio`| `registrarHorarioAcopio` | Crear un horario validando horas de apertura/cierre y un día aleatorio. | El objeto y su `DiaSemana` no son nulos. |
| **CP-ACOP-05** | `HorarioAcopio`| `probarDiaSemana` | Comprobar la asignación explícita del enumerador `DiaSemana`. | El día devuelto coincide con el asignado. |
| **CP-ACOP-06** | `HorarioAcopio`| `probarHorasAcopio` | Validar que los objetos `LocalTime` se guardan y recuperan sin alteraciones. | Las horas de apertura y cierre coinciden exactamente. |

---

## 3. Gestión de Donaciones (`GestionDonacionesTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-DON-01** | `Donacion` | `registrarDonacion` | Crear una donación con `LocalDateTime.now()` y forma de entrega aleatoria. | El objeto, fecha y forma de entrega no son nulos. |
| **CP-DON-02** | `Donacion` | `probarIdsYFechaDonacion` | Validar la correcta asignación de llaves foráneas lógicas y fechas estáticas. | Los IDs y la fecha devueltos coinciden con los de prueba. |
| **CP-DON-03** | `Donacion` | `probarFormaEntrega` | Verificar la asignación del enumerador `FormaEntrega`. | El enumerador coincide con el asignado. |
| **CP-DON-04** | `ItemDonado` | `registrarItemDonado` | Instanciar un ítem validando nombres de productos y unidades de medida. | El objeto y su descripción no son nulos. |
| **CP-DON-05** | `ItemDonado` | `probarDescripcionYCantidad` | Validar que la descripción y el número de cantidad se asignen correctamente. | Los valores devueltos son iguales a los introducidos. |
| **CP-DON-06** | `ItemDonado` | `probarUnidadMedida` | Comprobar la asignación del enumerador `UnidadMedida`. | La unidad de medida es idéntica a la asignada. |

---

## 4. Gestión de Emergencias (`GestionEmergenciasTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-EME-01** | `Emergencia` | `registrarEmergencia` | Instanciar una emergencia asignando dinámicamente dos enumeradores (Tipo y Estado). | El objeto, el tipo y el estado no son nulos. |
| **CP-EME-02** | `Emergencia` | `probarNombreYFechaEmergencia`| Validar la asignación de un nombre de crisis y su `LocalDateTime` de inicio. | El nombre y fecha coinciden con los valores estáticos. |
| **CP-EME-03** | `Emergencia` | `probarEstadoYTipoEmergencia` | Comprobar la asignación manual de `TipoEmergencia` y `EstadoEmergencia`. | Los enumeradores devueltos son los esperados. |
| **CP-EME-04** | `ZonaAfectada`| `registrarZonaAfectada` | Crear una zona afectada vinculando niveles de gravedad aleatorios. | El objeto y su nivel de gravedad no son nulos. |
| **CP-EME-05** | `ZonaAfectada`| `probarComunaCiudad` | Validar que el nombre de la localidad se persista en la instancia. | La comuna/ciudad devuelta coincide con la ingresada. |
| **CP-EME-06** | `ZonaAfectada`| `probarNivelGravedad` | Comprobar la asignación del enumerador `nivelGravedad`. | El nivel devuelto es el asignado explícitamente. |

---

## 5. Gestión de Inventario (`GestionInventarioTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-INV-01** | `InventarioStock` | `registrarInventarioStock` | Instanciar inventario asociando unidades de medida al azar. | El objeto, producto y unidad no son nulos. |
| **CP-INV-02** | `InventarioStock` | `probarNombreYCantidadStock`| Verificar la lectura y escritura del nombre del producto y su cantidad. | Los valores son iguales a los introducidos. |
| **CP-INV-03** | `InventarioStock` | `probarUnidadMedidaStock` | Validar el enumerador `UnidadMedida` específico de stock. | La unidad devuelta es correcta. |
| **CP-INV-04** | `MovimientoInv` | `registrarMovimientoInventario`| Crear un registro de movimiento testeando tipos y `LocalDateTime`. | Objeto, tipo de movimiento y fecha no son nulos. |
| **CP-INV-05** | `MovimientoInv` | `probarFechaYCantidadMovimiento`| Comprobar la inyección de enteros y fechas específicas en los atributos. | La cantidad y fecha esperadas coinciden. |
| **CP-INV-06** | `MovimientoInv` | `probarTipoMovimiento` | Verificar la asignación estática del enumerador `TipoMovimiento`. | El tipo de movimiento coincide. |

---

## 6. Gestión de Logística (`GestionLogisticaTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-LOG-01** | `Despacho` | `registrarDespacho` | Validar la creación de una ruta de despacho con estado aleatorio. | El despacho, su estado y fecha no son nulos. |
| **CP-LOG-02** | `Despacho` | `probarIdsYFechaDespacho` | Comprobar IDs de origen/destino y asignación de `LocalDateTime`. | Los IDs y la fecha devueltos coinciden con la prueba. |
| **CP-LOG-03** | `Despacho` | `probarEstadoDespacho` | Verificar el seteo manual del enumerador `EstadoDespacho`. | El estado coincide exactamente. |
| **CP-LOG-04** | `ItemDespachado` | `registrarItemDespachado` | Probar la instanciación de un ítem logístico. | Objeto y nombre de producto no son nulos. |
| **CP-LOG-05** | `ItemDespachado` | `probarNombreYCantidadItem`| Confirmar que la descripción y el número de carga se guardan correctamente. | El nombre y cantidad devueltos son los esperados. |

---

## 7. Gestión de Necesidades (`GestionNecesidadesTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-NEC-01** | `Necesidad` | `registrarNecesidad` | Crear un reporte de necesidad validando fechas actuales y estados. | Objeto, fecha de creación y estado no son nulos. |
| **CP-NEC-02** | `Necesidad` | `probarFechaCreacionNecesidad` | Validar inyección estática de `LocalDateTime` en la entidad. | La fecha de creación es la introducida en la prueba. |
| **CP-NEC-03** | `Necesidad` | `probarEstadoNecesidad` | Comprobar comportamiento del enumerador `EstadoNecesidad`. | El estado devuelto es el asignado. |
| **CP-NEC-04** | `DetalleNecesidad`| `registrarDetalleNecesidad`| Validar la relación de cantidades (recibidas vs solicitadas) y categorías. | El detalle y su categoría no son nulos. |
| **CP-NEC-05** | `DetalleNecesidad`| `probarCantidadesDetalle` | Verificar que los valores enteros asignados a cantidades se guarden bien. | Las cantidades devueltas son exactas a las insertadas. |
| **CP-NEC-06** | `DetalleNecesidad`| `probarCategoriaInsumo` | Validar el enumerador `CategoriaInsumo` de los detalles. | La categoría coincide con la esperada. |

---

## 8. Gestión de Notificaciones (`GestionNotificacionesTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-NOT-01** | `Notificacion` | `registrarNotificacion` | Generar alertas probando textos y doble asignación de Enums (Medio/Estado). | Objeto, mensaje, medio y estado actual no son nulos. |
| **CP-NOT-02** | `Notificacion` | `probarMensajeYDestinoNotificacion`| Verificar que el texto extenso y el ID de destino se mantengan íntegros. | El destino y el mensaje de texto coinciden. |
| **CP-NOT-03** | `Notificacion` | `probarEnumsNotificacion` | Validar seteo manual de `MedioEnvio` y `EstadoActual`. | Ambos enumeradores devueltos son correctos. |
| **CP-NOT-04** | `HistorialEnvio` | `registrarHistorialEnvio` | Instanciar el log de intentos testeando fecha de intento y estados. | Objeto, fecha y estado de envío no son nulos. |
| **CP-NOT-05** | `HistorialEnvio` | `probarFechaIntentoHistorial`| Comprobar la integridad temporal de la fecha inyectada. | La fecha recuperada coincide con la asignada. |
| **CP-NOT-06** | `HistorialEnvio` | `probarEstadoEnvioHistorial` | Validar enumerador `EstadoEnvio` para trazar envíos fallidos/exitosos. | El estado devuelto es el esperado. |

---

## 9. Gestión de Reportes (`GestionReportesTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-REP-01** | `MetricaCampana` | `registrarMetricaCampana` | Probar asignación de valores financieros/porcentuales (`BigDecimal`). | Objeto, porcentaje y nivel de transparencia no nulos. |
| **CP-REP-02** | `MetricaCampana` | `probarPorcentajeYIdsMetrica`| Validar la precisión de los decimales en `BigDecimal` contra un valor estático. | El valor de porcentaje y el ID de emergencia coinciden. |
| **CP-REP-03** | `MetricaCampana` | `probarNivelTransparencia` | Verificar enumerador de auditoría `NivelTransparencia`. | El nivel devuelto es exacto al asignado. |
| **CP-REP-04** | `DonanteDestacado`| `registrarDonanteDestacado` | Instanciar perfiles destacados con sumatoria de aportes y rangos al azar. | Objeto y rango de reconocimiento no son nulos. |
| **CP-REP-05** | `DonanteDestacado`| `probarAportesYUsuarioDonante`| Comprobar inyección de métricas enteras de alto valor (aportes). | Los IDs y el total de aportes coinciden. |
| **CP-REP-06** | `DonanteDestacado`| `probarRangoReconocimiento` | Validar el enumerador de fidelidad `RangoReconocimiento`. | El rango asignado se devuelve correctamente. |

---

## 10. Gestión de Voluntariado (`GestionVoluntariadoTest`)

| ID | Entidad | Método | Objetivo | Resultado Esperado |
| :--- | :--- | :--- | :--- | :--- |
| **CP-VOL-01** | `Voluntario` | `registrarVoluntario` | Verificar instanciación de perfiles probando validadores booleanos. | Objeto, área especialidad y disponibilidad no son nulos. |
| **CP-VOL-02** | `Voluntario` | `probarIdsYDisponibilidadVoluntario`| Comprobar la correcta asignación de llaves y booleanos explícitos. | Los valores (incluyendo `true` / `false`) coinciden. |
| **CP-VOL-03** | `Voluntario` | `probarAreaEspecialidad` | Validar el perfil competencial con el enumerador `AreaEspecialidad`. | El área coincide con la asignada. |
| **CP-VOL-04** | `AsignacionTurno`| `registrarAsignacionTurno` | Instanciar calendarios utilizando `LocalDate` en lugar de tiempos compuestos. | Objeto, fecha de turno y bloque horario no son nulos. |
| **CP-VOL-05** | `AsignacionTurno`| `probarAcopioYFechaTurno` | Confirmar que el objeto `LocalDate` es estable en la lectura de la entidad. | El ID de acopio y la fecha concuerdan exactamente. |
| **CP-VOL-06** | `AsignacionTurno`| `probarBloqueHorario` | Verificar la franja operativa con el enumerador `BloqueHorario`. | El bloque horario devuelto es correcto. |
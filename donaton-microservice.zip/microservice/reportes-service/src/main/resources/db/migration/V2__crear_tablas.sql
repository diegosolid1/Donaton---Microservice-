DROP TABLE IF EXISTS `donantedestacado`;
DROP TABLE IF EXISTS `metricacampana`;

-- Estructura de tabla para `metricacampana`
CREATE TABLE `metricacampana` (
                                  `id_metrica` INT NOT NULL AUTO_INCREMENT,
                                  `id_emergencia` INT NOT NULL,
                                  `porcentaje_cumplimiento` DECIMAL(5,2) NOT NULL,
                                  `nivel_transparencia` ENUM('Preliminar', 'Verificado', 'Auditado') NOT NULL,
                                  PRIMARY KEY (`id_metrica`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Estructura de tabla para `donantedestacado`
CREATE TABLE `donantedestacado` (
                                    `id_donante_destacado` INT NOT NULL AUTO_INCREMENT,
                                    `id_usuario` INT NOT NULL,
                                    `id_metrica` INT NOT NULL,
                                    `total_aportes_calculados` INT(11) NOT NULL,
                                    `rango_reconocimiento` ENUM('Bronce', 'Plata', 'Oro', 'Platino') NOT NULL,
                                    PRIMARY KEY (`id_donante_destacado`),
                                    KEY `fk_donante_metrica_campana` (`id_metrica`),
                                    CONSTRAINT `fk_donante_metrica_campana` FOREIGN KEY (`id_metrica`) REFERENCES `metricacampana` (`id_metrica`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
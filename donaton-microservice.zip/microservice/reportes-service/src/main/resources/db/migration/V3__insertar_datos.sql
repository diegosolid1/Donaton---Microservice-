-- Volcado de datos para la tabla `metricacampana`
INSERT INTO `metricacampana` (`id_metrica`, `id_emergencia`, `porcentaje_cumplimiento`, `nivel_transparencia`) VALUES
                                                                                                                   (1, 201, 50.00, 'Verificado'),
                                                                                                                   (2, 202, 75.50, 'Preliminar'),
                                                                                                                   (3, 203, 92.10, 'Verificado'),
                                                                                                                   (4, 204, 45.00, 'Preliminar'),
                                                                                                                   (5, 205, 100.00, 'Auditado'),
                                                                                                                   (6, 206, 88.45, 'Verificado'),
                                                                                                                   (7, 207, 15.30, 'Preliminar'),
                                                                                                                   (8, 208, 63.80, 'Verificado'),
                                                                                                                   (9, 209, 99.90, 'Auditado'),
                                                                                                                   (10, 210, 34.25, 'Preliminar');

-- Volcado de datos para la tabla `donantedestacado`
INSERT INTO `donantedestacado` (`id_donante_destacado`, `id_usuario`, `id_metrica`, `total_aportes_calculados`, `rango_reconocimiento`) VALUES
                                                                                                                                            (1, 101, 1, 50, 'Platino'),
                                                                                                                                            (2, 102, 2, 5, 'Bronce'),
                                                                                                                                            (3, 103, 3, 12, 'Plata'),
                                                                                                                                            (4, 104, 4, 28, 'Oro'),
                                                                                                                                            (5, 105, 5, 55, 'Platino'),
                                                                                                                                            (6, 106, 6, 3, 'Bronce'),
                                                                                                                                            (7, 107, 7, 15, 'Plata'),
                                                                                                                                            (8, 108, 8, 32, 'Oro'),
                                                                                                                                            (9, 109, 9, 7, 'Bronce'),
                                                                                                                                            (10, 110, 10, 21, 'Plata');
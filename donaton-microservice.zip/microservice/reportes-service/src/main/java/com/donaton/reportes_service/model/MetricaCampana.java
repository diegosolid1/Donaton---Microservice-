package com.donaton.reportes_service.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "metricacampana")
public class MetricaCampana {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_metrica")
    private Integer idMetrica;

    @NotNull(message = "El ID de la emergencia es obligatorio")
    @Column(name = "id_emergencia")
    private Integer idEmergencia;

    @NotNull(message = "El porcentaje de cumplimiento es obligatorio")
    @Column(name = "porcentaje_cumplimiento")
    private BigDecimal porcentajeCumplimiento;

    @NotNull(message = "El nivel de transparencia es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "nivel_transparencia")
    private NivelTransparencia nivelTransparencia;

    public enum NivelTransparencia {
        Preliminar,
        Verificado,
        Auditado;
    }

    @JsonIgnore
    @OneToMany(mappedBy = "metricaCampana", cascade = CascadeType.ALL)
    private List<DonanteDestacado> donantesDestacados;
}
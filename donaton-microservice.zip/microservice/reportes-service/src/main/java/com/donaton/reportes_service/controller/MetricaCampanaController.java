package com.donaton.reportes_service.controller;

import com.donaton.reportes_service.model.MetricaCampana;
import com.donaton.reportes_service.service.MetricaCampanaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/metrica-campana")
@Tag(name = "Métricas de Campañas", description = "Operaciones de seguimiento y análisis del rendimiento de campañas.")
public class MetricaCampanaController {

    @Autowired
    private MetricaCampanaService metricaCampanaService;

    @Operation(summary = "Listar todas las métricas de campañas.")
    @GetMapping
    public ResponseEntity<List<MetricaCampana>> listarMetricasCampana() {
        List<MetricaCampana> metricas = metricaCampanaService.getMetricasCampana();

        if (metricas.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(metricas);
        }
    }

    @Operation(summary = "Obtener una métrica de campaña por ID.")
    @GetMapping("/{id}")
    /* public ResponseEntity<MetricaCampana> buscarPorId(@PathVariable Integer id) { // Cambiado a Integer
        Optional<MetricaCampana> metrica = metricaCampanaService.getMetricaCampana(id);

        if (metrica.isPresent()) {
            return ResponseEntity.ok(metrica.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    } */
    public EntityModel<MetricaCampana> getMetricaCampana(@PathVariable Integer id) {

        MetricaCampana metricaCampana = metricaCampanaService.getMetricaCampana(id).orElseThrow();
        EntityModel<MetricaCampana> model = EntityModel.of(metricaCampana);

        model.add(
                linkTo(
                        methodOn(MetricaCampanaController.class)
                                .getMetricaCampana(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva métrica de campaña.")
    @PostMapping
    public ResponseEntity<MetricaCampana> agregarMetricaCampana(@Valid @RequestBody MetricaCampana metricaCampana) {
        try {
            MetricaCampana nuevaMetrica = metricaCampanaService.saveMetricaCampana(metricaCampana);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevaMetrica);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar una métrica de campaña existente.")
    @PutMapping("/{id}")
    public ResponseEntity<MetricaCampana> editarMetricaCampana(@Valid @RequestBody MetricaCampana metricaCampana, @PathVariable Integer id) { // Cambiado a Integer
        Optional<MetricaCampana> existe = metricaCampanaService.getMetricaCampana(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        metricaCampana.setIdMetrica(id);
        try {
            MetricaCampana actualizada = metricaCampanaService.saveMetricaCampana(metricaCampana);
            return ResponseEntity.ok(actualizada);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar una métrica de campaña por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarMetricaCampana(@PathVariable Integer id) { // Cambiado a Integer
        try {
            metricaCampanaService.deleteMetricaCampana(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
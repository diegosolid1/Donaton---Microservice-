package com.donaton.reportes_service.service;

import com.donaton.reportes_service.model.MetricaCampana;
import com.donaton.reportes_service.repository.MetricaCampanaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MetricaCampanaService {

    @Autowired
    private MetricaCampanaRepository metricaCampanaRepository;

    public List<MetricaCampana> getMetricasCampana() {
        return metricaCampanaRepository.findAll();
    }

    public Optional<MetricaCampana> getMetricaCampana(Integer id) {
        return metricaCampanaRepository.findById(id);
    }

    public MetricaCampana saveMetricaCampana(MetricaCampana metricaCampana) {
        return metricaCampanaRepository.save(metricaCampana);
    }

    public MetricaCampana updateMetricaCampana(Integer id, MetricaCampana metricaCampana) {
        Optional<MetricaCampana> existe = getMetricaCampana(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Métrica de campaña no encontrada con el ID: " + id);
        } else {
            metricaCampana.setIdMetrica(id);
            return metricaCampanaRepository.save(metricaCampana);
        }
    }

    public void deleteMetricaCampana(Integer id) {
        if (metricaCampanaRepository.existsById(id)) {
            metricaCampanaRepository.deleteById(id);
        } else {
            throw new RuntimeException("Métrica de campaña no encontrada con el ID: " + id);
        }
    }
}
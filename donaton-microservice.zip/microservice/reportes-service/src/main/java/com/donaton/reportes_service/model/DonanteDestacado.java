package com.donaton.reportes_service.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "donantedestacado")
public class DonanteDestacado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_donante_destacado")
    private Integer idDonanteDestacado;

    @NotNull(message = "El ID de usuario es obligatorio")
    @Column(name = "id_usuario")
    private Integer idUsuario;

    @NotNull(message = "La métrica de la campaña es obligatoria")
    @ManyToOne
    @JoinColumn(name = "id_metrica")
    private MetricaCampana metricaCampana;

    @NotNull(message = "El total de aportes calculados es obligatorio")
    @Column(name = "total_aportes_calculados")
    private Integer totalAportesCalculados;

    @NotNull(message = "El rango de reconocimiento es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "rango_reconocimiento", columnDefinition = "ENUM('Bronce', 'Plata', 'Oro', 'Platino')")
    private RangoReconocimiento rangoReconocimiento;

    public enum RangoReconocimiento {
        Bronce,
        Plata,
        Oro,
        Platino;
    }
}
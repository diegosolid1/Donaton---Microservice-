package com.donaton.reportes_service.service;

import com.donaton.reportes_service.model.DonanteDestacado;
import com.donaton.reportes_service.repository.DonanteDestacadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DonanteDestacadoService {

    @Autowired
    private DonanteDestacadoRepository donanteDestacadoRepository;

    public List<DonanteDestacado> getDonantesDestacados() {
        return donanteDestacadoRepository.findAll();
    }

    public Optional<DonanteDestacado> getDonanteDestacado(Integer id) {
        return donanteDestacadoRepository.findById(id);
    }

    public DonanteDestacado saveDonanteDestacado(DonanteDestacado donanteDestacado) {
        return donanteDestacadoRepository.save(donanteDestacado);
    }

    public DonanteDestacado updateDonanteDestacado(Integer id, DonanteDestacado donanteDestacado) {
        Optional<DonanteDestacado> existe = getDonanteDestacado(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Donante destacado no encontrado con el ID: " + id);
        } else {
            donanteDestacado.setIdDonanteDestacado(id);
            return donanteDestacadoRepository.save(donanteDestacado);
        }
    }

    public void deleteDonanteDestacado(Integer id) {
        if (donanteDestacadoRepository.existsById(id)) {
            donanteDestacadoRepository.deleteById(id);
        } else {
            throw new RuntimeException("Donante destacado no encontrado con el ID: " + id);
        }
    }
}
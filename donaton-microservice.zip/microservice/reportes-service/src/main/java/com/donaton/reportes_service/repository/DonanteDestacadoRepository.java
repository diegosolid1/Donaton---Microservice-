package com.donaton.reportes_service.repository;

import com.donaton.reportes_service.model.DonanteDestacado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DonanteDestacadoRepository extends JpaRepository<DonanteDestacado, Integer> {

}
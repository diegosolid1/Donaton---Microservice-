package com.donaton.reportes_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI(){
        return new OpenAPI()
                .info(new Info()
                        .title("API de Gestión de Reportes")
                        .version("1.0")
                        .description("Microservicio para la gestión de reportes: "
                                +
                                "Donante destacado y métricas de campaña.")
                        
                );

    }
}

package com.donaton.reportes_service.repository;

import com.donaton.reportes_service.model.MetricaCampana;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MetricaCampanaRepository extends JpaRepository<MetricaCampana, Integer> {

}
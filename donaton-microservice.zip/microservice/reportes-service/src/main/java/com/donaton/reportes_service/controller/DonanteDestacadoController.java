package com.donaton.reportes_service.controller;

import com.donaton.reportes_service.model.DonanteDestacado;
import com.donaton.reportes_service.service.DonanteDestacadoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/donante-destacado")
@Tag(name = "Donantes Destacados", description = "Operaciones de gestión y reconocimiento de donantes destacados.")
public class DonanteDestacadoController {

    @Autowired
    private DonanteDestacadoService donanteDestacadoService;

    @Operation(summary = "Listar todos los donantes destacados.")
    @GetMapping
    public ResponseEntity<List<DonanteDestacado>> listarDonantesDestacados() {
        List<DonanteDestacado> donantes = donanteDestacadoService.getDonantesDestacados();

        if (donantes.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(donantes);
        }
    }

    @Operation(summary = "Obtener un donante destacado por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<DonanteDestacado> buscarPorId(@PathVariable Integer id) { // Cambiado a Integer
        Optional<DonanteDestacado> donante = donanteDestacadoService.getDonanteDestacado(id);

        if (donante.isPresent()) {
            return ResponseEntity.ok(donante.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    } */
    public EntityModel<DonanteDestacado> getDonanteDestacado(@PathVariable Integer id) {

        DonanteDestacado donanteDestacado = donanteDestacadoService.getDonanteDestacado(id).orElseThrow();
        EntityModel<DonanteDestacado> model = EntityModel.of(donanteDestacado);

        model.add(
                linkTo(
                        methodOn(DonanteDestacadoController.class)
                                .getDonanteDestacado(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar un nuevo donante destacado.")
    @PostMapping
    public ResponseEntity<DonanteDestacado> agregarDonanteDestacado(@Valid @RequestBody DonanteDestacado donanteDestacado) {
        try {
            DonanteDestacado nuevoDonante = donanteDestacadoService.saveDonanteDestacado(donanteDestacado);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoDonante);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Actualizar un donante destacado existente.")
    @PutMapping("/{id}")
    public ResponseEntity<DonanteDestacado> editarDonanteDestacado(@Valid @RequestBody DonanteDestacado donanteDestacado, @PathVariable Integer id) { // Cambiado a Integer
        Optional<DonanteDestacado> existe = donanteDestacadoService.getDonanteDestacado(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        donanteDestacado.setIdDonanteDestacado(id);
        try {
            DonanteDestacado actualizado = donanteDestacadoService.saveDonanteDestacado(donanteDestacado);
            return ResponseEntity.ok(actualizado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(summary = "Eliminar un donante destacado por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDonanteDestacado(@PathVariable Integer id) { // Cambiado a Integer
        try {
            donanteDestacadoService.deleteDonanteDestacado(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }


}
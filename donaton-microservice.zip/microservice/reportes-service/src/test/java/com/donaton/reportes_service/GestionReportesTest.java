package com.donaton.reportes_service;

import com.donaton.reportes_service.model.DonanteDestacado;
import com.donaton.reportes_service.model.MetricaCampana;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionReportesTest {

    // ==========================================
    // TESTS DE MÉTRICA DE CAMPAÑA
    // ==========================================

    @Test
    void registrarMetricaCampana() {
        MetricaCampana metrica = new MetricaCampana();
        Faker faker = new Faker();

        metrica.setIdMetrica(faker.number().positive());
        metrica.setIdEmergencia(faker.number().positive());

        // Generar un número decimal entre 0 y 100 para el porcentaje de cumplimiento
        double porcentajeAleatorio = faker.number().randomDouble(2, 0, 100);
        metrica.setPorcentajeCumplimiento(BigDecimal.valueOf(porcentajeAleatorio));

        // Obtener un nivel de transparencia aleatorio del Enum
        MetricaCampana.NivelTransparencia[] niveles = MetricaCampana.NivelTransparencia.values();
        MetricaCampana.NivelTransparencia nivelAleatorio = niveles[faker.random().nextInt(niveles.length)];
        metrica.setNivelTransparencia(nivelAleatorio);

        System.out.println("ID Métrica: " + metrica.getIdMetrica());
        System.out.println("ID Emergencia: " + metrica.getIdEmergencia());
        System.out.println("Porcentaje Cumplimiento: " + metrica.getPorcentajeCumplimiento() + "%");
        System.out.println("Nivel Transparencia: " + metrica.getNivelTransparencia());

        assertNotNull(metrica);
        assertNotNull(metrica.getPorcentajeCumplimiento());
        assertNotNull(metrica.getNivelTransparencia());
    }

    @Test
    void probarPorcentajeYIdsMetrica() {
        MetricaCampana metrica = new MetricaCampana();

        Integer idEmergenciaEsperado = 8;
        BigDecimal porcentajeEsperado = new BigDecimal("85.50");

        metrica.setIdEmergencia(idEmergenciaEsperado);
        metrica.setPorcentajeCumplimiento(porcentajeEsperado);

        System.out.println("ID Emergencia asignado: " + metrica.getIdEmergencia());
        System.out.println("Porcentaje asignado: " + metrica.getPorcentajeCumplimiento() + "%");

        assertEquals(idEmergenciaEsperado, metrica.getIdEmergencia());
        assertEquals(porcentajeEsperado, metrica.getPorcentajeCumplimiento());
    }

    @Test
    void probarNivelTransparencia() {
        MetricaCampana metrica = new MetricaCampana();

        MetricaCampana.NivelTransparencia nivelEsperado = MetricaCampana.NivelTransparencia.Auditado;
        metrica.setNivelTransparencia(nivelEsperado);

        System.out.println("Nivel de transparencia asignado: " + metrica.getNivelTransparencia());

        assertEquals(nivelEsperado, metrica.getNivelTransparencia());
    }

    // ==========================================
    // TESTS DE DONANTE DESTACADO
    // ==========================================

    @Test
    void registrarDonanteDestacado() {
        DonanteDestacado donante = new DonanteDestacado();
        Faker faker = new Faker();

        donante.setIdDonanteDestacado(faker.number().positive());
        donante.setIdUsuario(faker.number().positive());
        donante.setTotalAportesCalculados(faker.number().numberBetween(1, 5000));

        // Obtener un rango aleatorio del Enum
        DonanteDestacado.RangoReconocimiento[] rangos = DonanteDestacado.RangoReconocimiento.values();
        DonanteDestacado.RangoReconocimiento rangoAleatorio = rangos[faker.random().nextInt(rangos.length)];
        donante.setRangoReconocimiento(rangoAleatorio);

        System.out.println("ID Donante Destacado: " + donante.getIdDonanteDestacado());
        System.out.println("ID Usuario: " + donante.getIdUsuario());
        System.out.println("Total Aportes: " + donante.getTotalAportesCalculados());
        System.out.println("Rango Reconocimiento: " + donante.getRangoReconocimiento());

        assertNotNull(donante);
        assertNotNull(donante.getRangoReconocimiento());
    }

    @Test
    void probarAportesYUsuarioDonante() {
        DonanteDestacado donante = new DonanteDestacado();

        Integer idUsuarioEsperado = 105;
        Integer aportesEsperados = 350;

        donante.setIdUsuario(idUsuarioEsperado);
        donante.setTotalAportesCalculados(aportesEsperados);

        System.out.println("ID Usuario asignado: " + donante.getIdUsuario());
        System.out.println("Aportes asignados: " + donante.getTotalAportesCalculados());

        assertEquals(idUsuarioEsperado, donante.getIdUsuario());
        assertEquals(aportesEsperados, donante.getTotalAportesCalculados());
    }

    @Test
    void probarRangoReconocimiento() {
        DonanteDestacado donante = new DonanteDestacado();

        DonanteDestacado.RangoReconocimiento rangoEsperado = DonanteDestacado.RangoReconocimiento.Oro;
        donante.setRangoReconocimiento(rangoEsperado);

        System.out.println("Rango asignado: " + donante.getRangoReconocimiento());

        assertEquals(rangoEsperado, donante.getRangoReconocimiento());
    }
}
package com.donaton.emergencias;

import com.donaton.emergencias.model.Emergencia;
import com.donaton.emergencias.model.ZonaAfectada;
import net.datafaker.Faker;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class GestionEmergenciasTest {

    // ==========================================
    // TESTS DE EMERGENCIA
    // ==========================================

    @Test
    void registrarEmergencia() {
        Emergencia emergencia = new Emergencia();
        Faker faker = new Faker();

        emergencia.setId(faker.number().positive());
        emergencia.setNombre("Emergencia en " + faker.address().cityName());
        emergencia.setFechaInicio(LocalDateTime.now());

        // Obtener tipo y estado aleatorio de los Enums
        Emergencia.TipoEmergencia[] tipos = Emergencia.TipoEmergencia.values();
        Emergencia.TipoEmergencia tipoAleatorio = tipos[faker.random().nextInt(tipos.length)];
        emergencia.setTipoEmergencia(tipoAleatorio);

        Emergencia.EstadoEmergencia[] estados = Emergencia.EstadoEmergencia.values();
        Emergencia.EstadoEmergencia estadoAleatorio = estados[faker.random().nextInt(estados.length)];
        emergencia.setEstado(estadoAleatorio);

        System.out.println("ID Emergencia: " + emergencia.getId());
        System.out.println("Nombre: " + emergencia.getNombre());
        System.out.println("Tipo: " + emergencia.getTipoEmergencia());
        System.out.println("Fecha Inicio: " + emergencia.getFechaInicio());
        System.out.println("Estado: " + emergencia.getEstado());

        assertNotNull(emergencia);
        assertNotNull(emergencia.getTipoEmergencia());
        assertNotNull(emergencia.getEstado());
    }

    @Test
    void probarNombreYFechaEmergencia() {
        Emergencia emergencia = new Emergencia();

        String nombreEsperado = "Aluvión Norte";
        LocalDateTime fechaEsperada = LocalDateTime.of(2026, 6, 10, 8, 0);

        emergencia.setNombre(nombreEsperado);
        emergencia.setFechaInicio(fechaEsperada);

        System.out.println("Nombre asignado: " + emergencia.getNombre());
        System.out.println("Fecha inicio asignada: " + emergencia.getFechaInicio());

        assertEquals(nombreEsperado, emergencia.getNombre());
        assertEquals(fechaEsperada, emergencia.getFechaInicio());
    }

    @Test
    void probarEstadoYTipoEmergencia() {
        Emergencia emergencia = new Emergencia();

        Emergencia.TipoEmergencia tipoEsperado = Emergencia.TipoEmergencia.Inundacion;
        Emergencia.EstadoEmergencia estadoEsperado = Emergencia.EstadoEmergencia.Activa;

        emergencia.setTipoEmergencia(tipoEsperado);
        emergencia.setEstado(estadoEsperado);

        System.out.println("Tipo asignado: " + emergencia.getTipoEmergencia());
        System.out.println("Estado asignado: " + emergencia.getEstado());

        assertEquals(tipoEsperado, emergencia.getTipoEmergencia());
        assertEquals(estadoEsperado, emergencia.getEstado());
    }

    // ==========================================
    // TESTS DE ZONA AFECTADA
    // ==========================================

    @Test
    void registrarZonaAfectada() {
        ZonaAfectada zona = new ZonaAfectada();
        Faker faker = new Faker();

        zona.setId(faker.number().positive());
        zona.setComunaCiudad(faker.address().cityName());

        // Obtener un nivel de gravedad aleatorio del Enum
        ZonaAfectada.nivelGravedad[] niveles = ZonaAfectada.nivelGravedad.values();
        ZonaAfectada.nivelGravedad nivelAleatorio = niveles[faker.random().nextInt(niveles.length)];
        zona.setNivelGravedad(nivelAleatorio);

        System.out.println("ID Zona: " + zona.getId());
        System.out.println("Comuna/Ciudad: " + zona.getComunaCiudad());
        System.out.println("Nivel Gravedad: " + zona.getNivelGravedad());

        assertNotNull(zona);
        assertNotNull(zona.getNivelGravedad());
    }

    @Test
    void probarComunaCiudad() {
        ZonaAfectada zona = new ZonaAfectada();
        Faker faker = new Faker();

        String comunaEsperada = faker.address().cityName();
        zona.setComunaCiudad(comunaEsperada);

        System.out.println("Comuna/Ciudad asignada: " + zona.getComunaCiudad());

        assertEquals(comunaEsperada, zona.getComunaCiudad());
    }

    @Test
    void probarNivelGravedad() {
        ZonaAfectada zona = new ZonaAfectada();

        ZonaAfectada.nivelGravedad nivelEsperado = ZonaAfectada.nivelGravedad.Critico;
        zona.setNivelGravedad(nivelEsperado);

        System.out.println("Nivel de gravedad asignado: " + zona.getNivelGravedad());

        assertEquals(nivelEsperado, zona.getNivelGravedad());
    }
}

package com.donaton.emergencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmergenciaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

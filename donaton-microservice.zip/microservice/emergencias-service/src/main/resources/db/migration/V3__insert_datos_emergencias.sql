
INSERT INTO Emergencia (nombre, tipo, fecha_inicio, estado)
VALUES
    ('Incendio Forestal Valparaíso', 'Incendio', '2026-02-15 14:30:00', 'Finalizada'),
    ('Inundación por Desborde Biobío', 'Inundacion', '2026-05-20 08:00:00', 'Activa'),
    ('Sismo Mayor Coquimbo', 'Terremoto', '2026-05-22 23:15:42', 'Controlada'),
    ('Brote Influenza Tipo A', 'Pandemia', '2026-04-01 00:00:00', 'Activa');


INSERT INTO ZonaAfectada (id_emergencia, comuna_ciudad, nivel_gravedad)
VALUES

(1, 'Valparaíso', 'Critico'),
(1, 'Viña del Mar', 'Alto'),


(2, 'Concepción', 'Medio'),
(2, 'Chiguayante', 'Alto'),
(2, 'San Pedro de la Paz', 'Bajo'),


(3, 'Coquimbo', 'Alto'),
(3, 'La Serena', 'Medio'),


(4, 'Santiago Centro', 'Alto'),
(4, 'Puente Alto', 'Medio');
CREATE TABLE Emergencia (

                            id INT AUTO_INCREMENT PRIMARY KEY,

                            nombre VARCHAR(100) NOT NULL,

                            tipo ENUM('Terremoto', 'Inundacion', 'Incendio', 'Pandemia', 'Otro') NOT NULL,

                            fecha_inicio DATETIME NOT NULL,

                            estado ENUM('Activa', 'Controlada', 'Finalizada') NOT NULL

);



CREATE TABLE ZonaAfectada (

                              id INT AUTO_INCREMENT PRIMARY KEY,

                              id_emergencia INT NOT NULL,

                              comuna_ciudad VARCHAR(100) NOT NULL,

                              nivel_gravedad ENUM('Bajo', 'Medio', 'Alto', 'Critico') NOT NULL,



                              CONSTRAINT fk_zona_emergencia

                                  FOREIGN KEY (id_emergencia)

                                      REFERENCES Emergencia(id)

                                      ON DELETE CASCADE

                                      ON UPDATE CASCADE

);
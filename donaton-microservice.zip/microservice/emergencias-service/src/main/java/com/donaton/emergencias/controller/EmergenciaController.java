package com.donaton.emergencias.controller;

import com.donaton.emergencias.model.Emergencia;
import com.donaton.emergencias.service.EmergenciaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/emergencia")
@Tag(name = "Emergencias", description = "Operaciones de gestión de emergencias.")
public class EmergenciaController {

    @Autowired
    private EmergenciaService emergenciaService;

    @Operation(summary = "Listar todas las emergencias.")
    @GetMapping
    public ResponseEntity<List<Emergencia>> listarEmergencias() {
        List<Emergencia> emergencias = emergenciaService.listarTodos();

        if (emergencias.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(emergencias); // 200
        }
    }

    @Operation(summary = "Obtener una emergencia por ID.")
    @GetMapping("/{id}")
    /*public ResponseEntity<Emergencia> ObtenerPorID(@PathVariable Integer id) {
        Optional<Emergencia> emergencia = emergenciaService.buscarPorId(id);

        if (emergencia.isPresent()) {
            return ResponseEntity.ok(emergencia.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    } */

    public EntityModel<Emergencia> getEmergencia(@PathVariable Integer id) {

        Emergencia emergencia = emergenciaService.buscarPorId(id).orElseThrow();
        EntityModel<Emergencia> model = EntityModel.of(emergencia);

        model.add(
                linkTo(
                        methodOn(EmergenciaController.class)
                                .getEmergencia(id)).withSelfRel()
        );
        return model;
    }

    @Operation(summary = "Registrar una nueva emergencia.")
    @PostMapping
    public ResponseEntity<Emergencia> crear(@Valid @RequestBody Emergencia emergencia) {
        Emergencia nuevaEmergencia = emergenciaService.guardar(emergencia);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevaEmergencia);
    }


    @Operation(summary = "Actualizar una emergencia existente.")
    @PutMapping("/{id}")
    public ResponseEntity<Emergencia> editarEmergencia(@Valid @RequestBody Emergencia emergencia, @PathVariable Integer id) {
        Optional<Emergencia> existe = emergenciaService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        emergencia.setId(id); // Seteamos el ID correspondiente a Emergencia
        Emergencia actualizado = emergenciaService.actualizar(id, emergencia);
        return ResponseEntity.ok(actualizado); // 200
    }


    @Operation(summary = "Eliminar una emergencia por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        Optional<Emergencia> existe = emergenciaService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            emergenciaService.eliminar(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
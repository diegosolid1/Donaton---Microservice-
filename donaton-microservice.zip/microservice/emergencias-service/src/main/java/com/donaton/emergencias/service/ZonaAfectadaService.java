package com.donaton.emergencias.service;

import com.donaton.emergencias.model.ZonaAfectada;
import com.donaton.emergencias.repository.ZonaAfectadaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public class ZonaAfectadaService {

    @Autowired
    private ZonaAfectadaRepository zonaAfectadaRepository;

    public List<ZonaAfectada> listarTodos() {
        return zonaAfectadaRepository.findAll();
    }

    public Optional<ZonaAfectada> buscarPorId(Integer id) {
        return zonaAfectadaRepository.findById(id);
    }

    public ZonaAfectada guardar(ZonaAfectada zonaAfectada) {
        return zonaAfectadaRepository.save(zonaAfectada);
    }

    public void eliminar(Integer id) {
        zonaAfectadaRepository.deleteById(id);
    }

    public ZonaAfectada actualizar(Integer id, ZonaAfectada zonaAfectada) {
        Optional<ZonaAfectada> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("La Zona Afectada no fue encontrada con el ID: " + id);
        } else {

            zonaAfectada.setId(id);
            return zonaAfectadaRepository.save(zonaAfectada);
        }
    }


}

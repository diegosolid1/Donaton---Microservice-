package com.donaton.emergencias.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Table(name = "zonaafectada")
@NoArgsConstructor
@AllArgsConstructor
public class ZonaAfectada {

    public enum nivelGravedad {
        Bajo,
        Medio,
        Alto,
        Critico
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotBlank(message = "La comuna o ciudad es obligatorio")
    @Size(max = 100, message = "La comuna o ciudad no puede superar los 100 caracteres")
    @Column(name = "comuna_ciudad")
    private String comunaCiudad;

    @NotNull(message = "El nivel de gravedad es obligatorio")
    @Enumerated(EnumType.STRING) // Guarda el texto del ENUM ('Activa', 'Controlada', etc.) en la BD
    @Column(name = "nivel_gravedad")
    private nivelGravedad nivelGravedad;

    @NotNull(message = "El tipo de emergencia es obligatorio")
    @ManyToOne
    @JoinColumn(name = "id_emergencia")
    private Emergencia emergencia;

}

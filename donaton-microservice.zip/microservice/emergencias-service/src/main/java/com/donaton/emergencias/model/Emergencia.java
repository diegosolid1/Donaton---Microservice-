package com.donaton.emergencias.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Table(name = "emergencia")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Emergencia {


    public enum TipoEmergencia {
        Terremoto,
        Inundacion,
        Incendio,
        Pandemia,
        Otro
    }

    public enum EstadoEmergencia {
        Activa,
        Controlada,
        Finalizada
    }


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100, message = "El nombre no puede superar los 100 caracteres")
    @Column(name = "nombre")
    private String nombre;

    @NotNull(message = "El nombre del Rol es obligatorio")
    @Enumerated(EnumType.STRING)//Permite guardar el enum como string en la base de datos
    @Column(name = "tipo")
    private TipoEmergencia tipoEmergencia;

    @Column(name = "fecha_inicio")
    @NotNull(message = "La fecha de inicio es obligatoria")
    private LocalDateTime fechaInicio; //YYY-MM-DD HH:MM:SS ASI SE MANEJA

    @NotNull(message = "El estado de la crisis es obligatorio")
    @Enumerated(EnumType.STRING)
    @Column(name = "estado")
    private EstadoEmergencia estado;

    // ... otros atributos ...

    @JsonIgnore
    @OneToMany(mappedBy = "emergencia", cascade = CascadeType.ALL)
    private List<ZonaAfectada> zonasAfectadas;

}
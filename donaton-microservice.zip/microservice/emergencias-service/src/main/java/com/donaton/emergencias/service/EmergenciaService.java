package com.donaton.emergencias.service;

import com.donaton.emergencias.model.Emergencia;
import com.donaton.emergencias.repository.EmergenciaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmergenciaService {

    @Autowired
    private EmergenciaRepository emergenciaRepository;

    public List<Emergencia> listarTodos() {
        return emergenciaRepository.findAll();
    }

    public Optional<Emergencia> buscarPorId(Integer id) {
        return emergenciaRepository.findById(id);
    }

    public Emergencia guardar(Emergencia emergencia) {
        return emergenciaRepository.save(emergencia);
    }

    public void eliminar(Integer id) {
        // 1. Verificamos si existe en la base de datos
        if (!emergenciaRepository.existsById(id)) {
            // Si no existe, lanzamos este error con el mensaje que queramos
            throw new EntityNotFoundException("No se pudo eliminar: La emergencia con ID " + id + " no existe.");
        }

        // 2. Si existe, lo borramos con tranquilidad
        emergenciaRepository.deleteById(id);
    }

    public Emergencia actualizar(Integer id, Emergencia emergencia) {
        Optional<Emergencia> existe = buscarPorId(id);
        if (existe.isEmpty()) {
            throw new RuntimeException("Emergencia no encontrada con el ID: " + id);
        } else {

            emergencia.setId(id);
            return emergenciaRepository.save(emergencia);
        }
    }


}

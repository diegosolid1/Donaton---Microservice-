package com.donaton.emergencias.controller;

import com.donaton.emergencias.model.ZonaAfectada;
import com.donaton.emergencias.service.ZonaAfectadaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("api/v1/zona")
@Tag(name = "Zonas Afectadas", description = "Operaciones de gestión de zonas afectadas.")
public class ZonaAfectadaController {

    @Autowired
    private ZonaAfectadaService zonaAfectadaService;


    @Operation(summary = "Listar todas las zonas afectadas.")
    @GetMapping
    public ResponseEntity<List<ZonaAfectada>> listarZonasAfectadas() {
        List<ZonaAfectada> zonas = zonaAfectadaService.listarTodos();

        if (zonas.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204
        } else {
            return ResponseEntity.ok(zonas); // 200
        }
    }


    @Operation(summary = "Obtener una zona afectada por ID.")
    @GetMapping("/{id}")
   /* public ResponseEntity<ZonaAfectada> ObtenerPorID(@PathVariable Integer id) {
        Optional<ZonaAfectada> zonaAfectada = zonaAfectadaService.buscarPorId(id);

        if (zonaAfectada.isPresent()) {
            return ResponseEntity.ok(zonaAfectada.get()); // 200
        } else {
            return ResponseEntity.notFound().build(); // 404
        }
    }*/
    public EntityModel<ZonaAfectada> getZonaAfectada(@PathVariable Integer id) {

        ZonaAfectada zonaAfectada = zonaAfectadaService.buscarPorId(id).orElseThrow();
        EntityModel<ZonaAfectada> model = EntityModel.of(zonaAfectada);

        model.add(
                linkTo(
                        methodOn(ZonaAfectadaController.class)
                                .getZonaAfectada(id)).withSelfRel()
        );
        return model;
    }


    @Operation(summary = "Registrar una nueva zona afectada.")
    @PostMapping
    public ResponseEntity<ZonaAfectada> crear(@Valid @RequestBody ZonaAfectada zonaAfectada) {
        ZonaAfectada nuevaZonaAfectada = zonaAfectadaService.guardar(zonaAfectada);
        return ResponseEntity
                .status(HttpStatus.CREATED) // 201
                .body(nuevaZonaAfectada);
    }


    @Operation(summary = "Actualizar una zona afectada existente.")
    @PutMapping("/{id}")
    public ResponseEntity<ZonaAfectada> editarZonaAfectada(@Valid @RequestBody ZonaAfectada zonaAfectada, @PathVariable Integer id) {
        Optional<ZonaAfectada> existe = zonaAfectadaService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        zonaAfectada.setId(id); // Seteamos el ID correspondiente a ZonaAfectada
        ZonaAfectada actualizado = zonaAfectadaService.actualizar(id, zonaAfectada);
        return ResponseEntity.ok(actualizado); // 200
    }


    @Operation(summary = "Eliminar una zona afectada por ID.")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        Optional<ZonaAfectada> existe = zonaAfectadaService.buscarPorId(id);

        if (existe.isEmpty()) {
            return ResponseEntity.notFound().build(); // 404
        }

        try {
            zonaAfectadaService.eliminar(id);
            return ResponseEntity.noContent().build(); // 204
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // 404
        }
    }
}
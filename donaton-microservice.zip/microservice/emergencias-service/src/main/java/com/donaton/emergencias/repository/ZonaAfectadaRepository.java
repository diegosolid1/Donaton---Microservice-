package com.donaton.emergencias.repository;

import com.donaton.emergencias.model.ZonaAfectada;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ZonaAfectadaRepository extends JpaRepository<ZonaAfectada, Integer> {
}
